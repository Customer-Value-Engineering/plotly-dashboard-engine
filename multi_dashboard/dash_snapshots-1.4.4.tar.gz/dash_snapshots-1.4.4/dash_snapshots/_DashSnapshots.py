import json
import os
import textwrap
import time
import traceback

from . import constants
from .store import Store
from .store.database import coerce_database_url
from . import server
from .tasks import _save_pdf
from .helpers import get_current_username
from .ArchiveTable import ArchiveTable
from functools import wraps
from ._utils import get_relative_path as fallback_get_relative_path
DEFAULT = object()


def _acl(method):
    @wraps(method)
    def wrapper(self, *args, **kwargs):
        if self._permissions == 'creator':
            username = get_current_username(self)
            if method.__name__ == 'snapshot_list':
                kwargs['filter_by'] = {"username": username}
            else:
                snapshot_id = args[0]
                try:
                    snapshot_owner = self.store._meta_get(snapshot_id, "username")
                    if username != snapshot_owner:
                        raise Exception
                except:
                    raise Exception("ACL error")
        return method(self, *args, **kwargs)
    return wrapper


class DashSnapshots:
    """
    The high-level interface for creating, retrieving, and updating
    Dash snapshots.

    Arguments:
    - `app` - A Dash app instance
    - `permissions` - Either `anyone` or `creator`.
    The default is `anyone` which means any users can view the snapshots.
    If set to `creator`, users can only access the snapshots that belong to them.
    - `database_url` (String) - A database URL where to store data.
    The typical form of a database URL is
    `dialect+driver://username:password@host:port/database`.
    If not set, it will use the URL in the environment variable `SNAPSHOT_DATABASE_URL`.
    If this is also not set, snapshots are stored to a Redis
    instance with the URL in the environment variable `REDIS_URL` or
    `redis://127.0.0.1:6379`.
    Note that the Postgres URL is available in the Dash Enterprise environment under the variable
    `DATABASE_URL` which you can retrieve with `os.environ.get('DATABASE_URL')`.
    Note that currently, the supported dialects are `sqlite`, `postgresql` and `redis`.
    When using an SQL database, Dash snapshots will automatically create tables
    with names `snapshot` and `blob`.
    When using `postgresql` and no driver is defined in the database URL,
    it will use driver `psycopg2` if the package is installed
    or else use `pg8000`.
    """

    def __init__(self, app, database_url=None, permissions='anyone', get_relative_path=None):
        if database_url is None:
            database_url = os.environ.get("SNAPSHOT_DATABASE_URL", False) or \
                os.environ.get("REDIS_URL", "redis://127.0.0.1:6379")

        # set view permissions
        if permissions not in ['anyone', 'creator']:
            raise Exception("Argument permissions should be 'anyone' or 'creator'.")
        self._permissions = permissions

        # stash DASH_ENTERPRISE_ENV
        self._dash_enterprise_env = os.environ.get("DASH_ENTERPRISE_ENV", "")

        # check whether this Dash app is embedded or not
        self._embedded = getattr(app, '_embedded', False)

        # Initialize database
        self.store = Store(app.server, database_url, self._dash_enterprise_env)

        # add HTTP routes
        if self._embedded is False:
            server._add_http_routes(app.server, self.store, self._permissions)

        # stash helper methods
        def handler(path):
            return fallback_get_relative_path(app.config.requests_pathname_prefix, path)

        self._get_relative_path = get_relative_path or getattr(app, "get_relative_path", handler)

    def relpath(self, path):
        """
        Construct a Dash Enterprise-aware relative URL paths.

        _Note: This function is now available in `dash` as `app.get_relative_path`.
        We recommend using `app.get_relative_path` going forward. We may deprecate
        `snap.relpath` in the future._

        Apps deployed on Dash Enterprise are prefixed with the
        name of the application.
        That is, instead of visiting http://localhost:8050, you visit
        http://your-dds-server.com/your-app-name/

        This function prefixes relative paths with the name of your application
        (as found in the ENV variable `DASH_APP_NAME`).

        That is, on DDS, `relpath('/assets/logo.png')` returns `/your-app-name/assets/logo.png`
        whereas in your development environment it will return `/assets/logo.png`.

        Examples:
        - Serving assets: `html.Img(src=snap.relpath('/assets/logo.png'))`
        - Using relative paths with the `dcc.Location` `pathname` property:
        ```python
        @app.callback(Output('content', 'children'), [Input('url', 'pathname')])
        def display_content(pathname):
            if pathname is None or pathname == snap.relpath('/'):
                return main_view()
            elif pathname == snap.relpath('/archive'):
                return archive()
            elif pathname.startswith(snap.relpath('/snapshot-')):
                snapshot_id = pathname.replace('/', '')
                return view_snapshot(snapshot_id)
            else:
                return '404'
        ```
        """
        return self._get_relative_path(path)

    #
    # Celery integration
    #
    @property
    def celery_instance(self):
        if "REDIS_URL" not in os.environ:
            msg = """
                REDIS_URL is not in the env.

                celery needs to be run in an
                environment that has access to Redis &
                `REDIS_URL` needs to be available as an environment variable.
                """
            if "DASH_APP_NAME" in os.environ:
                msg += """
                If this app is deployed on Dash Enterprise,
                then create a Redis instance and link it to this app:
                https://dash.plotly.com/dash-deployment-server/redis-database
                """
            raise Exception(textwrap.dedent(msg))

        if not hasattr(self, "_celery_instance"):
            import celery

            self._celery_instance = celery.Celery("celery")

            uri = coerce_database_url(os.environ["REDIS_URL"])
            default_serializer = 'json'
            self._celery_instance.conf.update({
                "broker_url": uri,
                "accept_content": ["json"],
                "task_serializer": default_serializer,
                "DASH_ENTERPRISE_ENV": self._dash_enterprise_env
            })
        return self._celery_instance

    def _worker_count(self):
        if hasattr(self, "_celery_instance"):
            active_workers = self._celery_instance.control.inspect().ping()
            if active_workers is None:
                return 0
            active_workers = self._worker_same_workspace(active_workers)
            return len(active_workers)
        else:
            return 0

    def _worker_stats(self):
        if hasattr(self, "_celery_instance"):
            stats = self._celery_instance.control.inspect().stats()
            if stats is None:
                return {}
            stats = self._worker_same_workspace(stats)
            return stats
        else:
            return {}

    def _worker_same_workspace(self, d):
        # Look for workers in the same env
        worker_conf = self._celery_instance.control.inspect().conf()
        if worker_conf is None:
            worker_conf = {}
        worker_conf = {key: value for (key, value) in worker_conf.items() if value["DASH_ENTERPRISE_ENV"] == self._dash_enterprise_env}
        return {w: d[w] for w in worker_conf}

    #
    # Python API V1 - storage
    #
    @_acl
    def snapshot_get(self, snapshot_id):
        """
        Retrieve a snapshot. This is whatever was saved with `snapshot_save`,
        `snapshot_save_async`, or `snapshot_save_periodic`.
        If a Dash component was saved, then this snapshot can be rendered in
         `children` within a `html.Div`.

        Arguments:
        - `snapshot_id` - The ID of the snapshot
        """
        blob = self.store._get_blob(snapshot_id, constants.KEYS["layout-json"])
        if blob is None:
            raise Exception("blob '{}' does not exist in '{}'".format(constants.KEYS["layout-json"], snapshot_id))
        else:
            return json.loads(blob)

    @_acl
    def snapshot_list(self, **kwargs):
        """
        Return a list of all available snapshot IDs sorted in descending order by time of creation.
        """
        # if we're not filtering by username
        if self._permissions == 'anyone':
            kwargs.pop('filter_by', None)  # filter_by should not be available
        return [row[0] for row in self.store._query_recent([], [], **kwargs)]

    @_acl
    def meta_get(self, snapshot_id, key, default=DEFAULT):
        """
        Retrieve a metadata property associated with a particular `snapshot_id`.

        Certain metadata keys are saved automatically with the snapshot.
        The names of these keys are available in `dash_snapshots.constants.KEYS`.
        Arbitrary metadata key-value pairs can be saved explicitly with `meta_update`. See all available keys associated with a particular snapshot with `meta_keys`.

        Arguments
        - `snapshot_id` - The ID of the snapshot
        - `key` - The particular key to retrieve.
        - `default` - If not `None`, then set a return a default value. If `None` and the key is not available, then raise an `Exception`.
        """
        # TODO - Explicit serializer
        try:
            return self.store._meta_get(snapshot_id, key)
        except Exception as e:
            if default is DEFAULT:
                raise e
            else:
                return default

    @_acl
    def meta_keys(self, snapshot_id):
        """
        Return all keys associated with a particular snapshot.

        Arguments:
        - `snapshot_id` - The snapshot ID.
        """
        keys = self.store._meta_keys(snapshot_id)
        return list(filter(lambda x: x[0] != '_', keys))

    @_acl
    def meta_update(self, snapshot_id, items_dict):
        """
        Save multiple key value pairs as part of a particular snapshot.

        Arguments:
        - `snapshot_id` - The snapshot ID
        - `items_dict` - A dictionary of items to save. All values will be serialized as JSON strings.
        """
        return self.store._meta_update(snapshot_id, items_dict)

    def snapshot_save(self, snapshot):
        """
        Save the snapshot to the database and return the unique
        ID of the snapshot.
        The snapshot is commonly a Dash component or
        a dataframe serialized as `df.to_dict('records')`.
        This snapshot can be any Python object that can be serialized to
        JSON using the `plotly.utils.PlotlyJSONEncoder` serializer:
        ```
        json.dumps(df.to_dict('records'), cls=plotly.utils.PlotlyJSONEncoder)
        ```

        Arguments:
        - `snapshot` - The Python object to be serialized as JSON and saved
        to the database.
        """
        (snapshot_id, created_time_formatted) = self.store._snapshot_save_init()

        self.store._save_component_tree(snapshot_id, snapshot)
        return snapshot_id

    @_acl
    def snapshot_delete(self, snapshot_id):
        """
        Deletes a snapshot along with its associated blobs

        Arguments:
        - `snapshot_id` - The snapshot ID.
        """
        return self.store._snapshot_delete(snapshot_id)

    @_acl
    def get_blob(self, snapshot_id, key):
        """
        Retrieves a blob associated with a snapshot

        Arguments:
        - `snapshot_id` - The snapshot ID.
        - `key` - The name of the blob.
        """
        return self.store._get_blob(snapshot_id, key)

    @_acl
    def save_blob(self, snapshot_id, key, data):
        """
        Save a blob associated with a snapshot

        Arguments:
        - `snapshot_id` - The snapshot ID.
        - `key` - The name of the blob.
        - `data` - A blob of data which is turned into bytes
        """
        return self.store._save_blob(snapshot_id, key, data)

    #
    # Python API V1 - queueing
    #
    def snapshot_async_wrapper(
        self,
        save_pdf=False,
        pdf_page_size="Letter",
        pdf_orientation="portrait",
        pdf_wait=20,
        pdf_margins=False,
        pdf_ignore_wait_exception=False,
        pdf_ssl_verify=None,
    ):
        """
        A decorator that saves whatever is returned by the
        decorated (or "wrapped") function to the database.
        The decorated function commonly returns a Dash component or
        a dataframe serialized as `df.to_dict('records')`.
        This function will save anything that can be JSON serializable
        using the `plotly.utils.PlotlyJSONEncoder` serializer:
        ```
        json.dumps(df.to_dict('records'), cls=plotly.utils.PlotlyJSONEncoder)
        ```

        This decorator should itself be decorated by
        `snap.celery_instance.task`:
        ```
        @snap.celery_instance.task
        @snap.snapshot_async_wrapper(save_pdf=True)
        def save_snapshot_in_background(figure_1, figure_2, figure_3):
            # For example, save some figures:
            return {'figure-1': figure_1, 'figure-2': figure_2, 'figure-3': figure_3}
        ```

        With these decorators, the decorated function can be passed
        into `snapshot_save_async` or `snapshot_save_periodic`:
        ```python
        @app.callback(...)
        def save_snapshot(...):
            snap.snapshot_save_async(
                save_snapshot_in_background,
                figure_1, figure_2, figure_3
            )
        ```
        These functions will be executed in a separate process with Celery.

        This decorator will save the component as well as additional metadata
        about the task such as when the task started and finished or the task's
        error message.

        In addition to the interactive snapshot,
        this decorator can also save a PDF view of the snapshot if `save_pdf=True`.

        There are various options parameters available when saving a PDF
        and these arguments are prefixed with `pdf_`.

        Arguments
        - `save_pdf` - If True, then save a PDF of the snapshot after
        saving the interactive version. This functionality is only available
        when deploying an application to Dash Enterprise: it is not available
        in your local development environment nor within a Dash Enterprise Workspace.
        - `pdf_page_size` - The size of the PDF.
        `page_size` can be one of `"Letter"`, `"A3"`, `"A4"`, `"A5"`,
        `"Legal"`, `"Tabloid"`, or a dict with shape `{"width": ..., "height": ...}`
        where width and height are integers specified in microns.
        - `pdf_orientation` can be one of `"portrait", "landscape"`.
        - `pdf_wait` - (Integer) The number of seconds to wait for the page to render
        before capturing a PDF.

        In DashSnapshots < `1.3.1`, `pdf_wait` could also be set to a string.
        This is now deprecated: we recommend using an integer instead.
        If set to a string, then it should be set to a CSS selector contained on the page.
        The PDF generation API will wait wait until an element that matches this CSS selector
        appears on the screen before taking a screenshot.
        - `pdf_margins` - If True, then margins will be added to the page.
        - `pdf_ignore_wait_exception` - By default, the PDF generation times out after 30 seconds
        on Dash Enterprise and so specifying a `pdf_wait` integer greater than 30 will throw an exception.
        If you increased this in the Dash Enterprise Server Manager, set to True to ignore this exception.
        - `pdf_ssl_verify` - Can be `True`, `False`, or `None`. If False, requests made to the image
        generation endpoint will not require valid SSL credentials. This is necessary if your Server uses
        self-signed certificates. If `None`, then `dash-snapshots` will defer to the value set in an environment
        variable called `PDF_SSL_VERIFY` in your app and default to True if it is not found.
        """
        # TODO - functools

        def scoped_decorator(func):
            def wrapper(*args, **kwargs):
                if self.store._is_sql_database:
                    # To prevent issue with multiprocessing:
                    # https://docs.sqlalchemy.org/en/13/core/connections.html#engine-disposal
                    self.store.db.engine.dispose()

                # Retrieve current context
                self.context = kwargs.pop(constants.SNAPSHOT_CONTEXT)

                # Get pdf_url
                pdf_url = self.context.get("pdf_url", None)

                # In periodic tasks, the initialization won't be performed
                # in a dash callback (i.e. from `snapshot_save_async`),
                # so perform it here.
                if "snapshot_id" not in self.context:
                    self.context["snapshot_id"] = self.store._snapshot_async_init()

                snapshot_id = self.context["snapshot_id"]
                username = self.context["username"]

                try:
                    self.meta_update(
                        snapshot_id,
                        {
                            constants.KEYS["task_start_time"]: time.strftime(
                                "%Y-%m-%d %X"
                            )
                        },
                    )

                    # this func could take a long time - e.g. hours
                    component_tree = func(*args, **kwargs)

                    self.store._save_component_tree(snapshot_id, component_tree)

                    if save_pdf:
                        _save_pdf(
                            username,
                            self.relpath,
                            self.store,
                            snapshot_id,
                            self._embedded,
                            page_size=pdf_page_size,
                            orientation=pdf_orientation,
                            wait=pdf_wait,
                            margins=pdf_margins,
                            ignore_wait_exception=pdf_ignore_wait_exception,
                            ssl_verify=pdf_ssl_verify,
                            pdf_url=pdf_url
                        )

                    self.meta_update(
                        snapshot_id,
                        {
                            constants.KEYS["task_finish_time"]: time.strftime(
                                "%Y-%m-%d %X"
                            ),
                            constants.KEYS["pdf"]: snapshot_id
                        },
                    )
                    context = self.context
                    delattr(self, "context")
                    return context

                except Exception as e:
                    print(
                        "Error in `snapshot_async_wrapper`:\n"
                        "- snapshot_id: {}\n"
                        "- function name: {}".format(snapshot_id, func.__name__)
                    )
                    traceback.print_exc()
                    print(e)
                    self.meta_update(snapshot_id, {"error": str(e)})
                    delattr(self, "context")
                    raise e

            return wrapper

        return scoped_decorator

    def snapshot_save_periodic(self, func, *func_args, **func_kwargs):
        """
        Function to aid saving snapshots periodically via Celery.

        When `snapshot_save_periodic` is called, `dash_snapshots` submits
        `func` to the Celery task queue to be executed in a separate process
        periodically.

        This function is meant to be embedded in Celery's
        `add_periodic_task` method:
        ```
        @celery_instance.task
        @snap.snapshot_async_wrapper(save_pdf=True)
        def generate_snapshot():
            # This function is run in a separate task queue managed by celery
            # The task is submitted periodically via `setup_periodic_tasks` and
            # on-the-fly via a callback on the home page.

            # Whatever is returned by this function will be saved to the database
            # with the `snapshot_id`. It needs to be JSON-serializable

            return ddk.Report([
                ddk.Page(html.H1('Hello World'))
            ])


        # Set up a periodic scheduler that will call the `generate_snapshot` function
        # every 30 minutes via the `crontab` scheduler
        @celery_instance.on_after_configure.connect
        def setup_periodic_tasks(sender, **kwargs):
            # See more examples in the celery documentation (https://docs.celeryproject.org/en/latest/userguide/periodic-tasks.html) or in this nice
            # crontab cheatsheet (https://crontab.guru/examples.html)
            # Run every 30 minutes
            cron_task_schedule = crontab(minute='*/30', hour='*', day_of_week='*', month_of_year='*')
            sender.add_periodic_task(
                cron_task_schedule,
                snap.snapshot_save_periodic(
                    generate_snapshot,
                ),
                # This name is optional, it will appear in the logs
                # and can be helpful if you are running multiple tasks
                name="generate snapshot every 30 min",
            )
        ```

        Arguments:
        - `func` - A function that returns a Python object (snapshot) that can be saved to the database.
        It is expected that this function is
        decorated by `@celery_instance.task` & `@snap.snapshot_async_wrapper()`.
        The snapshot is commonly a Dash component or
        a dataframe serialized as `df.to_dict('records')`.
        This snapshot can be any Python object that can be serialized to
        JSON using the `plotly.utils.PlotlyJSONEncoder` serializer:
        ```
        json.dumps(df.to_dict('records'), cls=plotly.utils.PlotlyJSONEncoder)
        ```
        - `func_args`- Positional arguments to be passed into
        `func` when it is periodically called.
        - `link` - A function that is automatically called when the snapshot has finished saving. This function must be decorated by `@celery_instance.task`. This function is called with a `dict` with the shape `{'snapshot_id': <your-snapshot-id>}`. If `None`, only `func` will be called.
        A linked task is function call decorated by @celery_instance.task. `link` will chain
        this task call after `func` in @snap.snapshot_async_wrapper() as one execution workflow.
        Linking makes this task to be executed periodically whenever `func` executes successfully.
        If `None`, only `func` will be called.
        - `func_kwargs`- Keyword arguments to be passed into
        `func` when it is periodically called.
        """
        # func is wrapped in async_wrapper
        # so, anything that we need to do in the task we can
        # do there.

        # By default, primary task in @snap.snapshot_async_wrapper() returns a dictionary
        # {"snapshot_id": snapshot_id}, which will be passed as first argument to its linked task.
        link = func_kwargs.pop("link", None)

        # Pass context
        func_kwargs[constants.SNAPSHOT_CONTEXT] = {
            "username": get_current_username()
        }
        return func.signature(args=func_args, kwargs=func_kwargs, options={'link': link})

    def snapshot_save_async(self, func, *func_args, **func_kwargs):
        """
        Function to aid saving snapshots asynchronously via Celery.

        When `snapshot_save_async` is called, `dash_snapshots` submits
        `func` to the Celery task queue to be executed in a separate process.

        Whatever `func` returns is saved in the database.

        Arguments:
        - `func` - A function that returns a Python object (snapshot) that can be saved to the database.
        It is expected that this function is
        decorated by `@celery_instance.task` & `@snap.snapshot_async_wrapper()`.
        The snapshot is commonly a Dash component or
        a dataframe serialized as `df.to_dict('records')`.
        This snapshot can be any Python object that can be serialized to
        JSON using the `plotly.utils.PlotlyJSONEncoder` serializer:
        ```
        json.dumps(df.to_dict('records'), cls=plotly.utils.PlotlyJSONEncoder)
        ```
        - `func_args`- Positional arguments to be passed into `func` when it is asynchronously called.
        - `func_kwargs`- Keyword arguments to be passed into `func` when it is periodically called.
            Note that the following keyword arguments are special and are not passed into `func`:
            - `link` - A function that is automatically called when the snapshot has finished saving. This function must be decorated by `@celery_instance.task`. This function is called with a `dict` with the shape `{'snapshot_id': <your-snapshot-id>}`. If `None`, only `func` will be called.
            A linked task is function call decorated by @celery_instance.task. `link` will chain
            this task call after `func` in @snap.snapshot_async_wrapper() as one execution workflow.
            Linking makes this task to be executed periodically whenever `func` executes successfully.
            If `None`, only `func` will be called.
            - `pdf_url` - A string representing the URL to visit to generate a PDF of the snapshot. This should only be specified if snapshots are not served at the typical URL `https://{domain}/{app}/{snapshot_id}?print=true`.
            The values for `domain`, `app` and `snapshot_id` will be injected into the provided `pdf_url` via Python's `format()` method.
            By default, this is `'`https://{domain}/{app}/{snapshot_id}?print=true'`.
            If your report page is different, for example `https://dash.acme.com/your-app/report/snap-asdk-13kbd`, then set this to `'https://{domain}/{app}/report/{snapshot_id}?print=true'`.
            Note that you should add `?print=true` to the end of the URL. This is used implicitly by the
            `ddk.Report` & `ddk.Page` components to apply PDF-ready styles & CSS.

        """
        link = func_kwargs.pop("link", None)
        pdf_url = func_kwargs.pop("pdf_url", None)
        # By default, primary task in @snap.snapshot_async_wrapper() returns a dictionary
        # {"snapshot_id": snapshot_id}, which will be passed as first argument to its linked task.

        # TODO - Verify that the function was wrapped in `async_wrapper`
        snapshot_id = self.store._snapshot_async_init()
        # func is wrapped in async_wrapper
        # so, anything that we need to do in the task we can
        # do there.

        # Pass context
        func_kwargs[constants.SNAPSHOT_CONTEXT] = {
            "username": get_current_username(),
            "snapshot_id": snapshot_id,
            "pdf_url": pdf_url
        }
        func.apply_async(func_args, func_kwargs, link=link)

        return snapshot_id

    #
    # Dash components
    #
    def ArchiveTable(self, columns=None, version=2):
        """
        Return a `dash_table.DataTable` (for version 2) or a `html.Table` (for version 1) populated with a list of snapshots, their metadata keys, and links to the snapshot view.

        By default, this table will return all metadata keys associated with a snapshot and each metadata key will have its own column in the table. For the built-in metadata keys (the keys that are saved automatically on save - `dash_snapshots.constants.KEYS`), human readable column names are automatically supplied. For custom metadata keys that are saved as part of `meta_update`, `ArchiveTable` will display a capitalized version of the metadata key as the column name, with underscores and hyphens replaced by spaces.

        You can override the column names, which columns are displayed, and the order of the columns by passing in your own `columns` list. Each list item is a dict with `id` (the metadata key name) and `name` (the name of the column that `ArchiveTable` should use when rendering the table).

        For example:
        ```python
        snap.ArchiveTable(
            columns=[
                # These are "built-in" meta data options
                {
                    'id': dash_snapshots.constants.KEYS['snapshot_id'],
                    'name': ''
                },
                {
                    'id': dash_snapshots.constants.KEYS['username'],
                    'name': 'Creator',
                },
                {
                    'id': dash_snapshots.constants.KEYS['created_time'],
                    'name': 'Created Date'
                },

                # Example of a custom meta data key
                {
                    'id': 'city',
                    'name': 'City'
                }
            ]
        ])
        ```

        All metadata values are rendered as strings in the table with the exception of `snapshot_id`, which is rendered as a relative link to `/<snapshot-id>`.

        You can also render your own table by looping through `snap.snapshot_list` and retrieving the available meta data for each snapshot ID with `snap.meta_keys` and `snap.meta_get`.
        """
        if version not in [1, 2]:
            raise Exception("ArchiveTable version must be an integer between 1 and 2")

        filter_by = {}
        if self._permissions == 'creator':
            username = get_current_username(self)
            filter_by = {"username": username}

        return ArchiveTable(version, self.store, self.relpath, columns, filter_by=filter_by)
