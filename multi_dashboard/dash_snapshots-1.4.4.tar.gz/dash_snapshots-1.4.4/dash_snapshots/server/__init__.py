import flask
import io
from .. import constants
from .. import helpers
import os


def _add_http_routes(server, store, permissions):
    server.add_url_rule("/<snapshot_id>.pdf", "serve_pdfs", serve_pdfs(store, permissions))


# TODO - redis_key_prefix for running multiple apps locally
def serve_pdfs(store, permissions):
    def handler(**kwargs):
        snapshot_id = kwargs["snapshot_id"]

        if permissions == "creator":
            try:
                snapshot_owner = store._meta_get(snapshot_id, "username")
                if helpers.get_current_username() != snapshot_owner:
                    raise Exception("ACL error")
            except:
                return flask.make_response("""
                     Access forbidden
                """, 403)

        exists = store._blob_exists(snapshot_id, constants.KEYS["pdf"])
        if not exists:
            return flask.make_response("""
                Snapshot ({}) does not exist.
            """.format(snapshot_id), 404)

        # Retrieve PDF
        snapshot_binary = store._get_blob(snapshot_id, constants.KEYS["pdf"])

        if snapshot_binary is None:
            if "DASH_APP_NAME" not in os.environ:
                return flask.make_response("""
                The PDF view of this snapshot ({}) is not available -
                PDF snapshots are only available when the app is
                deployed on Dash Enterprise.
                """.format(
                    snapshot_id
                ), 501)

            return "The PDF view of this snapshot ({}) was not found.".format(snapshot_id)

        return flask.send_file(
            io.BytesIO(snapshot_binary),
            attachment_filename="{}.pdf".format(snapshot_id),
            mimetype="application/pdf",
        )

    return handler
