import json
import os
from setuptools import setup


with open("package.json") as f:
    package = json.load(f)

package_name = package["name"].replace(" ", "_").replace("-", "_")

setup(
    name=package_name,
    version=package["version"],
    author=package["author"],
    packages=[
        "dashboard_engine",
        "dashboard_engine/api",
        "dashboard_engine/api/elements",
    ],
    include_package_data=True,
    license=package["license"],
    description=package.get("description", package_name),
    install_requires=[
        "jsonschema==3.*",
        "fastjsonschema==2.*",
        "dash>=1.19.0",
        "nested_lookup==0.2.22",
        "pandas==1.*",
        "plotly==4.14.*",  # 4.14.3 is the minimum
        'cryptography<3.4;python_version<"3.7"',
        'vaex-core>=4.1',
        "dash_enterprise_auth",
    ],
    classifiers=["Framework :: Dash"],
)
