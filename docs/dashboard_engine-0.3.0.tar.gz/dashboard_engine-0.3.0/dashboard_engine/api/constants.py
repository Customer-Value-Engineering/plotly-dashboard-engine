import os


STYLE = {"padding": 0}
DATASHADER = os.getenv("DATASHADER", False)
DBE_EXPERIMENTAL_FEATURES = os.getenv("DBE_EXPERIMENTAL_FEATURES", False)
