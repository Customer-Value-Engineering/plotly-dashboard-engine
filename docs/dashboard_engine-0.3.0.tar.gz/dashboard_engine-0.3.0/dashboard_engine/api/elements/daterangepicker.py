import dash_core_components as dcc
import dash_html_components as html
from ..selection_query import SelectionQuery
from ._base_element import BaseElement


def get_date_range(element):
    selection = element.get("selections", [])
    if len(selection) == 0:
        return [None, None]
    else:
        return selection[0]["bounds"]


class DateRangePicker(BaseElement):
    label = "Date Range Picker"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def selection_query(element):
        return SelectionQuery(
            where=element.get("selections", []),
        )

    @staticmethod
    def handle_start_date(value, elements, index, data_schema):
        element = elements[index]
        _, end_date = get_date_range(element)
        element["selections"] = [
            {"type": "range", "column": element["date"], "bounds": [value, end_date]}
        ]

    @staticmethod
    def handle_end_date(value, elements, index, data_schema):
        element = elements[index]
        start_date, _ = get_date_range(element)
        element["selections"] = [
            {"type": "range", "column": element["date"], "bounds": [start_date, value]}
        ]

    @staticmethod
    def render(id, element, query_result, opts, data_schema):

        start_date, end_date = get_date_range(element)

        return html.Div(
            [
                html.Div(element.get("date", ""), className="control--label"),
                html.Div(
                    dcc.DatePickerRange(
                        id=id, start_date=start_date, end_date=end_date
                    ),
                    className="control--item",
                ),
            ],
            className="control label--top label--text--left",
        )

    @staticmethod
    def schema(data_schema):
        return {
            "jsonSchema": {
                "type": "object",
                "properties": {
                    "date": {"title": "Date column", "enum": data_schema.dates()},
                },
                "required": ["date"],
            }
        }
