import dash_html_components as html
from ._base_element import BaseElement


class Reset(BaseElement):
    label = "'Clear selections' button"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def handle_n_clicks(value, elements, index, data_schema):
        for element in elements:
            if "selections" in element:
                del element["selections"]

    @staticmethod
    def render(id, element, query_result, opts, data_schema):
        return html.Button("Clear selections", id=id)

    @staticmethod
    def schema(data_schema):
        return {"jsonSchema": {"type": "object", "properties": {}, "required": []}}
