from .dropdown import Dropdown
from .scatter import Scatter
from .table import Table
from .bar import Bar
from .indicator import Indicator
from .reset import Reset
from .daterangepicker import DateRangePicker
from .line import Line

from ._docstring import inject_docstring

# Inject docstrings
for el in [Dropdown, Scatter, Table, Bar, Indicator, Reset, DateRangePicker, Line]:
    inject_docstring(el)

__all__ = [
    "Bar",
    "Dropdown",
    "Table",
    "Scatter",
    "Indicator",
    "DateRangePicker",
    "Line",
    # this should come last until we skip processing inputs that haven't been triggered
    "Reset",
]
