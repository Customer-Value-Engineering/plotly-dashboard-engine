import dash_design_kit as ddk
from ._helpers import (
    make_selection_shapes,
    element_without_data,
    aggfuncs,
    make_label,
    make_cartesian_selection,
)
import plotly.express as px
import numpy as np
from ..selection_query import SelectionQuery
from ._base_element import BaseElement


class Line(BaseElement):
    label = "Line Chart"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def selection_query(element):
        attrs = [
            ("none", element["x"], "x"),
            (element.get("y_aggfunc", "none"), element["y"], "y"),
        ]
        color = element.get("color", None)
        if color is not None:
            attrs.append((element.get("color_aggfunc", "none"), color, "color"))

        select = [a for a in attrs if a[0] != "none"]
        group_by = [a for a in attrs if a[0] == "none"]

        return SelectionQuery(
            select=select,
            where=element.get("selections", []),
            group_by=group_by,
            where_mask_key="where_mask",
        )

    @staticmethod
    def handle_selectedData(value, elements, index, data_schema):  # noqa: N802
        element = elements[index]
        element["selections"] = make_cartesian_selection(
            ["x"], value, element, data_schema
        )

    @staticmethod
    def render(id, element, query_result, opts, data_schema):
        if query_result.is_empty():
            return element_without_data(id)

        x = element.get("x", None)
        y = element.get("y", None)
        color = element.get("color", None)
        y_aggfunc = element.get("y_aggfunc", "none")

        fig = px.line(
            query_result.df,
            x="x",
            y="y",
            color="color" if color else None,
            labels={"x": x, "y": make_label(y, y_aggfunc), "color": color},
            category_orders=query_result.make_category_orders({"x": x, "color": color}),
            color_discrete_map=query_result.make_color_map(color),
            custom_data=["where_mask"],  # TODO add PX feature for this in v5
        )
        fig.update_layout(
            dragmode="select",
            hovermode="closest",
            selectdirection="h",
            shapes=make_selection_shapes(element, directions=["x"]),
        )
        fig.update_traces(mode="lines+markers", marker=dict(opacity=0))
        for t in fig.data:
            t.selectedpoints = np.where(t.customdata.ravel())[0]
        if element["show_legend"]:
            fig.update_layout(legend_yanchor="bottom", legend_y=1)
        else:
            fig.update_layout(showlegend=False)
        return ddk.Graph(
            id=id,
            figure=fig,
            config={"modeBarButtonsToRemove": ["lasso2d"]},
        )

    @staticmethod
    def schema(
        data_schema,
    ):
        return {
            "jsonSchema": {
                "type": "object",
                "properties": {
                    "x": {"title": "X axis column", "enum": data_schema.all()},
                    "y": {"title": "Y axis column", "enum": data_schema.numeric()},
                    "color": {
                        "title": "Color column",
                        "enum": data_schema.discrete() + [None],
                    },
                    "show_legend": {
                        "title": "Show Legend",
                        "type": "boolean",
                        "default": True,
                    },
                },
                "dependencies": {
                    "y": {
                        "oneOf": [
                            {
                                "properties": {
                                    "y": {"enum": data_schema.numeric()},
                                    "y_aggfunc": {
                                        "title": "Y Aggregation method",
                                        "enum": ["none"] + aggfuncs,
                                        "default": "none",
                                    },
                                }
                            },
                            {"properties": {"y": {"enum": [None]}}},
                        ]
                    },
                },
                "required": ["x", "y"],
            },
            "uiSchema": {"ui:order": ["x", "y", "y_aggfunc", "color", "show_legend"]},
        }
