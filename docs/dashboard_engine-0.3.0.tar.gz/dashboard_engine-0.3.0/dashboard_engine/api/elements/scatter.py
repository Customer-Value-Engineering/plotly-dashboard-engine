import dash_design_kit as ddk
from ._helpers import (
    update_axis,
    make_selection_shapes,
    element_without_data,
    aggfuncs,
    make_label,
    make_cartesian_selection,
)
import plotly.express as px
import numpy as np
from ..selection_query import SelectionQuery
from ._base_element import BaseElement
from ..constants import DATASHADER, DBE_EXPERIMENTAL_FEATURES
import pandas as pd


class Scatter(BaseElement):
    label = "Scatter Plot"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def selection_query(element):
        selections = element.get("selections", [])
        local_where = [
            {"type": "range", "column": element[axis], "bounds": bounds}
            for axis, bounds in element.get("range", {}).items()
        ]
        if element.get("filter_on_relayout", False) is True:
            selections += local_where

        attrs = [
            ("none", element["x"], "x"),
            ("none", element["y"], "y"),
        ]
        color = element.get("color", None)
        if color is not None:
            attrs.append((element.get("color_aggfunc", "none"), color, "color"))

        size = element.get("size", None)
        if size is not None:
            attrs.append((element.get("size_aggfunc", "none"), size, "size"))

        select = [a for a in attrs if a[0] != "none"]
        group_by = [a for a in attrs if a[0] == "none"]

        return SelectionQuery(
            select=select,
            where=selections,
            local_where=local_where,
            group_by=group_by,
            where_mask_key="where_mask",
        )

    @staticmethod
    def handle_relayoutData(value, elements, index, data_schema):  # noqa: N802
        element = elements[index]
        element["range"] = element.get("range", {})
        for axis in ["x", "y"]:
            start = "{}axis.range[0]".format(axis)
            end = "{}axis.range[1]".format(axis)
            autorange = "{}axis.autorange".format(axis)
            if (
                value
                and start in value
                and end in value
                and data_schema.is_continuous(element[axis])
            ):
                element["range"][axis] = [value[start], value[end]]
            elif autorange in value and value[autorange] is True:
                element["range"].pop(axis, None)

        if "dragmode" in value:
            element["_dragmode"] = value["dragmode"]

    @staticmethod
    def handle_selectedData(value, elements, index, data_schema):  # noqa: N802
        element = elements[index]
        element["selections"] = make_cartesian_selection(
            ["x", "y"], value, element, data_schema
        )

    @staticmethod
    def render(id, element, query_result, opts, data_schema):
        if query_result.is_empty() and not element.get("range", {}):
            return element_without_data(id)

        if query_result.is_empty():
            df = pd.DataFrame(
                {"x": [], "y": [], "color": [], "size": [], "where_mask": []}
            )
        else:
            df = query_result.df

        x = element["x"]
        y = element["y"]
        color = element.get("color", None)
        color_aggfunc = element.get("color_aggfunc", "none")
        size = element.get("size", None)
        size_aggfunc = element.get("size_aggfunc", "none")

        if (
            DATASHADER
            and len(df.index) > 1e4
            and (data_schema.is_continuous(x))
            and (data_schema.is_continuous(y))
        ):
            import datashader
            import datashader.transfer_functions as tf

            cvs = datashader.Canvas(plot_width=512, plot_height=512)
            agg = cvs.points(df, x, y)
            img = tf.shade(agg)[::-1]
            fig = px.imshow(
                img.to_pil(), x=img.coords["x"], y=img.coords["y"], binary_string=True
            )

            # Add an overlay
            factor = 1.05
            element.setdefault(
                "range",
                dict(
                    x=[
                        img.coords["x"].values[0] * factor,
                        img.coords["x"].values[-1] * factor,
                    ],
                    y=[
                        img.coords["y"].values[-1] * factor,
                        img.coords["y"].values[0] * factor,
                    ],
                ),
            )
            fig.update_layout(shapes=make_selection_shapes(element, mode="overlay"))

            # Override magic axis defaults meant for images
            fig.update_layout(
                yaxis_autorange=False,
                xaxis_autorange=False,
                xaxis_constrain="range",
                yaxis_constrain="range",
            )
        else:
            fig = px.scatter(
                df,
                x="x",
                y="y",
                color="color" if color else None,
                size="size" if size else None,
                labels={
                    "x": x,
                    "y": y,
                    "size": make_label(size, size_aggfunc),
                    "color": make_label(color, color_aggfunc),
                },
                category_orders=query_result.make_category_orders(
                    {"x": x, "y": y, "color": color}
                ),
                color_discrete_map=query_result.make_color_map(color),
                custom_data=["where_mask"],
            )
            for t in fig.data:
                t.selectedpoints = np.where(t.customdata.ravel())[0]

            fig.update_layout(shapes=make_selection_shapes(element))

        fig.update_layout(dragmode=element.get("_dragmode", "select"), uirevision="yes")
        update_axis(fig, element)

        if element["show_legend"]:
            fig.update_layout(legend_yanchor="bottom", legend_y=1)
        else:
            fig.update_layout(showlegend=False)
        return ddk.Graph(
            id=id,
            figure=fig,
            config={"modeBarButtonsToRemove": ["lasso2d"]},
        )

    @staticmethod
    def schema(data_schema):

        schema = {
            "jsonSchema": {
                "type": "object",
                "properties": {
                    "x": {"title": "X axis column", "enum": data_schema.all()},
                    "y": {"title": "Y axis column", "enum": data_schema.all()},
                    "color": {
                        "title": "Color column",
                        "enum": data_schema.all() + [None],
                    },
                    "size": {
                        "title": "Size column",
                        "enum": data_schema.numeric() + [None],
                    },
                    "show_legend": {
                        "title": "Show Legend",
                        "type": "boolean",
                        "default": True,
                    },
                },
                "dependencies": {
                    "color": {
                        "oneOf": [
                            {
                                "properties": {
                                    "color": {"enum": data_schema.numeric()},
                                    "color_aggfunc": {
                                        "title": "Color aggregation method",
                                        "enum": ["none"] + aggfuncs,
                                        "default": "none",
                                    },
                                }
                            },
                            {
                                "properties": {
                                    "color": {
                                        "enum": data_schema.non_numeric() + [None]
                                    }
                                }
                            },
                        ]
                    },
                    "size": {
                        "oneOf": [
                            {
                                "properties": {
                                    "size": {"enum": data_schema.numeric()},
                                    "size_aggfunc": {
                                        "title": "Size aggregation method",
                                        "enum": ["none"] + aggfuncs,
                                        "default": "none",
                                    },
                                }
                            },
                            {"properties": {"size": {"enum": [None]}}},
                        ]
                    },
                },
                "required": ["x", "y"],
            },
            "uiSchema": {
                "ui:order": [
                    "x",
                    "y",
                    "color",
                    "color_aggfunc",
                    "size",
                    "size_aggfunc",
                    "show_legend",
                ]
            },
        }

        if DBE_EXPERIMENTAL_FEATURES:
            schema["jsonSchema"]["properties"]["filter_on_relayout"] = {
                "title": "Filter on zoom/pan",
                "type": "boolean",
                "default": False,
            }

        return schema
