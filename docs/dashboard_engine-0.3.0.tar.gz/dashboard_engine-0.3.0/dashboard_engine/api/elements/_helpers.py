from collections.abc import Iterable
import dash_html_components as html
import dash_design_kit as ddk


labels = dict(
    sum="Sum",
    count="Count",
    min="Minimum",
    max="Maximum",
    mean="Average",
    std="Standard Deviation",
)
aggfuncs = list(labels.keys())


def make_label(column, aggfunc):
    if aggfunc == "none":
        return column
    return "%s of %s" % (labels[aggfunc], column)


def flatten(list):
    for el in list:
        if isinstance(el, Iterable) and not isinstance(el, (str, bytes)):
            yield from flatten(el)
        else:
            yield el


def update_axis(fig, element):
    fig.update_layout(
        **{k + "axis_range": v for k, v in element.get("range", {}).items()}
    )


def make_cartesian_selection(axes, value, element, data_schema):
    selections = []
    for axis in axes:
        if value:
            if "points" in value and data_schema.is_discrete(element[axis]):
                added = set()
                unique_sorted_points = [
                    point[axis]
                    for point in value["points"]
                    if not (point[axis] in added or added.add(point[axis]))
                ]
                selections.append(
                    {
                        "type": "points",
                        "column": element[axis],
                        "values": unique_sorted_points,
                    }
                )

            elif "range" in value and data_schema.is_continuous(element[axis]):
                selections.append(
                    {
                        "type": "range",
                        "column": element[axis],
                        "bounds": value["range"][axis],
                    }
                )
    return selections


def make_selection_shapes(element, mode=None, directions=None):
    if directions is None:
        directions = ["x", "y"]
    axes = {}
    shapes = []
    selections = element.get("selections", [])

    for selection in selections:
        if "_rectangle" in selection:
            x = selection["_rectangle"]["x"]
            y = selection["_rectangle"]["y"]
            shapes.append(
                dict(
                    type="rect",
                    x0=x[0],
                    x1=x[1],
                    y0=y[0],
                    y1=y[1],
                    line=dict(width=1, dash="dot"),
                )
            )
            continue

        if "type" in selection and selection["type"] == "range":
            for axis in directions:
                if element.get(axis, None) == selection["column"]:
                    if axis not in axes:
                        axes[axis] = selection["bounds"]
                    else:
                        a0, a1 = axes[axis]
                        b0, b1 = selection["bounds"]
                        axes[axis] = [max(a0, b0), min(a1, b1)]

    if "x" in axes:
        x = axes["x"]
        if "y" in axes:
            y = axes["y"]
            yref = "y"
        else:
            y = [0, 1]
            yref = "paper"

        if x[0] < x[1] and y[0] < y[1]:
            shapes.append(
                dict(
                    type="rect",
                    x0=x[0],
                    x1=x[1],
                    yref=yref,
                    y0=y[0],
                    y1=y[1],
                    line=dict(width=1, dash="dot"),
                )
            )

    if mode == "overlay" and "x" in axes and "y" in axes:
        range = element["local_where"]["bounds"]
        shapes.append(
            dict(
                type="path",
                xref="x",
                xsizemode="scaled",
                yref="y",
                ysizemode="scaled",
                fillcolor="white",
                opacity=0.75,
                line=dict(width=0),
                path="M{} {} V{} H{} V{} H{} M{},{} H{} V{} H{} V{}".format(
                    range["x"][0],
                    range["y"][0],
                    range["y"][1],
                    range["x"][1],
                    range["y"][0],
                    range["x"][0],
                    axes["x"][1],
                    axes["y"][0],
                    axes["x"][0],
                    axes["y"][1],
                    axes["x"][1],
                    axes["y"][0],
                ),
            )
        )

    return shapes


def element_without_data(id):
    children = [ddk.Icon(icon_name="square", icon_category="regular")]

    children.append(html.P("No data available", style={"fontSize": "20px"}))

    return html.Div(
        className="placeholder", children=children
    )  # TODO: get DDK's theme color
