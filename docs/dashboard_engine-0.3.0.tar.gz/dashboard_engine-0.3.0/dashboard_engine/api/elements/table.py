import dash_table  # noqa: F401
from dash_table.Format import Format, Scheme
import dash_design_kit as ddk
from ._helpers import element_without_data, aggfuncs, make_label
from ..selection_query import SelectionQuery
from ._base_element import BaseElement


class Table(BaseElement):
    label = "Table"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def selection_query(element):
        order_by = [
            (s["column_id"], s["direction"]) for s in element.get("sort_by", [])
        ]

        attrs = [
            (c.get("aggfunc", "none"), c["column"], f"col_{i:03}")
            for i, c in enumerate(element["columns"])
        ]
        select = [a for a in attrs if a[0] != "none"]
        group_by = [a for a in attrs if a[0] == "none"]

        return SelectionQuery(select=select, order_by=order_by, group_by=group_by)

    @staticmethod
    def handle_page_current(page_current, elements, index, data_schema):
        elements[index]["page_current"] = page_current

    @staticmethod
    def handle_sort_by(sort_by, elements, index, data_schema):
        elements[index]["sort_by"] = sort_by

    @staticmethod
    def render(id, element, query_result, opts, data_schema):
        if query_result.is_empty():
            return element_without_data(id)
        df = query_result.df

        # Paging
        page_size = element.get("page_size", 10)
        page_current = element.get("page_current", 0)

        # Column type and formating
        columns = []
        for i, col in enumerate(sorted(df.columns)):
            col_type = str(df[col].dtype)
            datatable_type = DATATABLE_COLUMN_TYPES[col_type]

            # Retrieve associated column with this possibly aggregated metric
            column = element["columns"][i]
            name = make_label(column["column"], column.get("aggfunc", "none"))
            col_metadata = {
                "name": column.get("label", name),
                "id": col,
                "type": datatable_type,
            }

            # Specify formatting
            format = Format(
                precision=column.get("number_precision", None),
                scheme=getattr(Scheme, (column.get("number_format", "default"))),
            )
            if column.get("thousand_separator", False):
                format = format.group(True)
            col_metadata["format"] = format

            columns.append(col_metadata)

        return ddk.DataTable(
            id=id,
            columns=columns,
            data=df.iloc[
                page_current * page_size : (page_current + 1) * page_size
            ].to_dict("records"),
            page_size=page_size,
            page_current=page_current,
            page_action="custom",
            sort_by=element.get("sort_by", []),
            sort_action="custom",
            sort_mode="single",
        )

    @staticmethod
    def schema(data_schema):
        return {
            "uiSchema": {"columns": {"items": {"precision": {"ui:widget": "updown"}}}},
            "jsonSchema": {
                "type": "object",
                "properties": {
                    "columns": {
                        "title": "Columns",
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "column": {
                                    "title": "Column",
                                    "enum": data_schema.all(),
                                },
                                "label": {"title": "Label", "type": "string"},
                            },
                            "dependencies": {
                                "column": {
                                    "oneOf": [
                                        {
                                            "properties": {
                                                "column": {
                                                    "enum": data_schema.numeric()
                                                },
                                                "aggfunc": {
                                                    "title": "Aggregation method",
                                                    "enum": ["none"] + aggfuncs,
                                                    "default": "none",
                                                },
                                                "number_format": {
                                                    "title": "Number format",
                                                    "default": "default",
                                                    "enum": [
                                                        "default",
                                                        "decimal",
                                                        "decimal_integer",
                                                        "decimal_or_exponent",
                                                        "decimal_si_prefix",
                                                        "exponent",
                                                        "fixed",
                                                        "percentage",
                                                        "percentage_rounded",
                                                        "binary",
                                                        "octal",
                                                        "lower_case_hex",
                                                        "upper_case_hex",
                                                        "unicode",
                                                    ],
                                                    "enumNames": [
                                                        "Default",
                                                        "Decimal",
                                                        "Decimal or integer",
                                                        "Decimal or exponent",
                                                        "Decimal with SI prefix",
                                                        "Exponent",
                                                        "Fixed",
                                                        "Percentage",
                                                        "Percentage (rounded)",
                                                        "Binary",
                                                        "Octal",
                                                        "Hexadecimal (lowercase)",
                                                        "Hexadecimal (uppercase)",
                                                        "Unicode",
                                                    ],
                                                },
                                                "number_precision": {
                                                    "title": "Number precision",
                                                    "type": "integer",
                                                    "minimum": 0,
                                                    "maximum": 50,
                                                },
                                                "thousand_separator": {
                                                    "title": "Use thousands separator",
                                                    "type": "boolean",
                                                    "default": False,
                                                },
                                            }
                                        },
                                        {
                                            "properties": {
                                                "column": {
                                                    "enum": data_schema.non_numeric()
                                                    + [None]
                                                }
                                            }
                                        },
                                    ]
                                },
                            },
                            "required": ["column"],
                        },
                    },
                    "page_size": {
                        "title": "Page Size",
                        "type": "integer",
                        "minimum": 1,
                        "exclusiveMaximum": 50,
                    },
                },
                "required": ["columns"],
            },
        }


DATATABLE_COLUMN_TYPES = {
    "int64": "numeric",
    "float64": "numeric",
    "object": "any",
    "string": "any",
    "datetime64[ns]": "datetime",
}
