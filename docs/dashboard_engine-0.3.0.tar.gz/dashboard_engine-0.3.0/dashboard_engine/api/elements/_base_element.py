class BaseElement:
    def __init__(self, **kwargs):
        self._config = kwargs
