import dash_core_components as dcc
import dash_html_components as html
from ._helpers import flatten
from ..selection_query import SelectionQuery
from ._base_element import BaseElement


class Dropdown(BaseElement):
    label = "Dropdown Menu"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def selection_query(element):
        return SelectionQuery(
            where=element.get("selections", []),
        )

    @staticmethod
    def handle_value(value, elements, index, data_schema):
        element = elements[index]
        if value is None:
            # Delete selections so the default can take over
            element.pop("selections", None)
            return

        if isinstance(value, str) or not hasattr(value, "__iter__"):
            value = [value]
        element["selections"] = [
            {"type": "points", "column": element["value"], "values": [v for v in value]}
        ]

    @staticmethod
    def render(id, element, query_result, opts, data_schema):
        multi = element["multi"]
        value = []
        for sel in element.get("selections", []):
            for pt in sel["values"]:
                value.append(pt)

        value = list(flatten(value))
        labels = query_result.order_for_category(element["value"])
        if not multi:
            value = value[0] if len(value) > 0 else None

        return html.Div(
            [
                html.Div(element.get("value", ""), className="control--label"),
                html.Div(
                    dcc.Dropdown(
                        id=id,
                        options=[{"label": label, "value": label} for label in labels],
                        multi=multi,
                        value=value,
                        clearable=element["clearable"],
                    ),
                    className="control--item",
                ),
            ],
            className="control label--top label--text--left",
        )

    @staticmethod
    def schema(data_schema):

        return {
            "jsonSchema": {
                "type": "object",
                "properties": {
                    "value": {
                        "title": "Value column",
                        "enum": data_schema.low_cardinality(),
                    },
                    "clearable": {
                        "title": "Clearable",
                        "type": "boolean",
                        "default": True,
                    },
                    "multi": {
                        "title": "Allow multiple selections",
                        "type": "boolean",
                        "default": False,
                    },
                },
                "allOf": [
                    {
                        "if": {
                            "allOf": [
                                {"properties": {"value": {"const": col}}},
                                {"properties": {"clearable": {"const": False}}},
                            ]
                        },
                        "then": {
                            "properties": {
                                "selections": {
                                    "default": [
                                        {
                                            "type": "points",
                                            "column": col,
                                            "values": [data_schema.first_value(col)],
                                        }
                                    ]
                                }
                            }
                        },
                    }
                    for col in data_schema.low_cardinality()
                ],
                "required": ["value"],
            }
        }
