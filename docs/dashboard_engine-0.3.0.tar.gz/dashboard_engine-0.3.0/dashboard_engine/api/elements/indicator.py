import dash_design_kit as ddk
from ._helpers import element_without_data, aggfuncs, make_label
from ..selection_query import SelectionQuery
from ._base_element import BaseElement


class Indicator(BaseElement):
    label = "Indicator"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @staticmethod
    def selection_query(element):
        return SelectionQuery(
            select=[(element["aggregation"], element["value"], "value")]
        )

    @staticmethod
    def render(id, element, query_result, opts, data_schema):
        op = element.get("aggregation")
        label = make_label(element["value"], op)

        if query_result.is_empty():
            return element_without_data(id)

        return ddk.Graph(
            id=id,
            figure={
                "data": [
                    {
                        "type": "indicator",
                        "value": query_result.df["value"].iloc[0],
                        "mode": "number",
                        "title": {"text": element.get("title", label)},
                    }
                ],
                "layout": {"margin": {"t": 50, "r": 0, "l": 0, "b": 0}},
            },
        )

    @staticmethod
    def schema(data_schema):
        return {
            "jsonSchema": {
                "type": "object",
                "properties": {
                    "value": {
                        "title": "Value column",
                        "enum": data_schema.numeric(),
                    },
                    "aggregation": {
                        "type": "string",
                        "title": "Aggregation method",
                        "enum": aggfuncs,
                        "default": "mean",
                    },
                    "title": {"type": "string", "title": "Custom Title"},
                },
                "required": ["value"],
            }
        }
