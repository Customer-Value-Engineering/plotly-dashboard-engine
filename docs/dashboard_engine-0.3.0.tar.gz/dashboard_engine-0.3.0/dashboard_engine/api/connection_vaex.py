from functools import reduce
from operator import and_
import vaex
import re

from .connection import (
    DataFrameConnection,
    DataFrameConnectionProvider,
    dataframe_slice,
)
from .selection_query import SelectionQueryResult


def all_true(df):
    # trivial expression, maybe we can have a nicer solution for vaex
    first = df.get_column_names()[0]
    return df[first] == df[first]


def and_expressions(df, expressions):
    if len(expressions) == 0:
        return all_true(df)
    else:
        return reduce(and_, expressions)


def selection_expression_range(df, column_name, range):
    if None not in range:
        range.sort()
    if range[1] is None:
        return df[column_name] >= range[0]
    elif range[0] is None:
        return df[column_name] <= range[1]
    else:
        return (df[column_name] >= range[0]) & (df[column_name] <= range[1])


def selection_expression_points(df, selection):
    expressions = []
    column_name = selection["column"]
    for value in selection["values"]:
        expressions.append(df[column_name] == value)
    assert len(expressions) > 0
    return reduce(and_, expressions)


def selection_expression(df, selection):
    # Compute a vaex expression from where selection statements (single one)
    expressions = []
    if selection["type"] == "range":
        expressions.append(
            selection_expression_range(df, selection["column"], selection["bounds"])
        )

    if selection["type"] == "points":
        expressions.append(selection_expression_points(df, selection))
    return and_expressions(df, expressions)


def where_expression(df, where):
    # Compute a vaex expression from where statements
    return and_expressions(
        df,
        [selection_expression(df, selection) for selection in where if selection],
    )


def aggregate(df, select, group_by):
    # based on connection.py::aggregate
    key_to_label = {}
    grouping_cols = []
    aggregated_cols = {}
    aggregated_cols_nogroup = {}

    # processing for topN, numerical and date binning should go here
    for groupfunc, column, key in group_by:
        label = column
        key_to_label[key] = label
        if column not in grouping_cols:
            grouping_cols.append(column)

    # new aggregators like count-unique, weighted-mean etc should go here
    for aggfunc, column, key in select:
        label = "%s_%s" % (aggfunc, column)
        key_to_label[key] = label
        if label not in aggregated_cols:
            if aggfunc == "count":
                # count should count even non-null!
                aggregated_cols[label] = vaex.agg.count()
                aggregated_cols_nogroup[label] = ("count", "*")
            else:
                aggregated_cols[label] = getattr(vaex.agg, aggfunc)(df[column])
                aggregated_cols_nogroup[label] = (aggfunc, column)

    if len(df) == 0:
        for label in aggregated_cols:
            df[label] = ""
        return df, key_to_label

    if len(aggregated_cols) == 0:
        if len(grouping_cols) == 0:
            raise ValueError("nothing to aggregate!")
        # we use groupby to find unique elements
        unique_name = "count_that_should_be_dropped"
        result = (
            df.groupby(grouping_cols)
            .agg({unique_name: vaex.agg.count()})
            .drop(unique_name)
        )
    else:
        if grouping_cols:
            result = df.groupby(grouping_cols).agg(aggregated_cols)
        else:
            aggs = {
                name: df._compute_agg(
                    aggfunc, df[arg] if arg != "*" else arg, delay=True
                )
                for name, (aggfunc, arg) in aggregated_cols_nogroup.items()
            }
            df.execute()
            aggs = {name: result.get() for name, result in aggs.items()}
            result = vaex.from_scalars(**aggs)

    return result, key_to_label


class VaexConnection(DataFrameConnection):
    def query(self, selection_queries):
        """
        Perform a data query described by a list of SelectionQuery

        This method is responsible for querying data
        based on the provided list of SelectionQuery object.
        For each SelectionQuery provided in the list,
        a SelectionQueryResult is returned which contains data filtered based
        on every other SelectionQuery except its own.

        Typical usage example:

        ```py
        result = connection.query(
            [
                SelectionQuery(
                    where=[
                    {"type": "range", "column": "lifeExp", "bounds": [65, 70]},
                    {"type": "range", "column": "gdpPercap", "bounds": [15000, 20000]},
                    ],
                    group_by=[("none", "country")]
                ),
                SelectionQuery(group_by=[("none", "country")]), # select all
            ]
        )
        ```

        Arguments:
          - selection_queries (list of SelectionQuery):

        Returns:
          - list of SelectionQueryResult
        """
        results = []
        df = self._df
        filter_expressions = [
            where_expression(df, selection_query.where)
            if selection_query is not None
            else None
            for selection_query in selection_queries
        ]

        empty_result = SelectionQueryResult(
            None,
            {},
            self.order_for_category,
            self.colormap_for_category,
        )

        for i, selection_query in enumerate(selection_queries):
            if selection_query is None or (
                len(selection_query.select) == 0 and len(selection_query.group_by) == 0
            ):
                results.append(empty_result)
                continue

            element_filter_expressions = [
                e for j, e in enumerate(filter_expressions) if i != j and e is not None
            ]
            if selection_query.local_where:
                element_filter_expressions.append(
                    where_expression(df, selection_query.local_where)
                )
            element_filter_expression = and_expressions(df, element_filter_expressions)

            working_df = df.to_copy()
            extra_group_by = []
            if selection_query.where_mask_key:
                working_df["dbe_mask__"] = filter_expressions[i]
                extra_group_by = [
                    ("none", "dbe_mask__", selection_query.where_mask_key)
                ]

            # filter
            if element_filter_expression is not None:
                element_df = working_df[element_filter_expression]
            else:
                element_df = working_df

            if len(element_df) == 0:
                results.append(empty_result)
                continue

            # aggregate
            element_df, key_to_label = aggregate(
                element_df,
                selection_query.select,
                selection_query.group_by + extra_group_by,
            )

            # order
            if selection_query.order_by:
                assert (
                    len(selection_query.order_by) == 1
                )  # TODO: support multi columns sorting instead of only one
                element_df = element_df.sort(
                    key_to_label[selection_query.order_by[0][0]],
                    ascending=selection_query.order_by[0][1] == "asc",
                )

            # limit/offset
            element_df = dataframe_slice(
                element_df, selection_query.offset, selection_query.limit
            )

            results.append(
                SelectionQueryResult(
                    element_df.to_pandas_df(),
                    key_to_label,
                    self.order_for_category,
                    self.colormap_for_category,
                )
            )
        return results


class VaexConnectionProvider(DataFrameConnectionProvider):
    _cls = VaexConnection


class VaexFileConnectionProvider:
    """
    Vaex connection provider to data stored in a file

    If `connection_params` is a string, it is interpreted as a filepath.
    If it is a dict, its `url` value is interpreted as a filepath.
    Optionally, the key `parse_dates` can contain a list of column names
    which should be parsed as date.

    The file must have one of the following supported extension:
      - csv
      - parquet
      - hdf5
    """

    def get_connection(self, connection_params, user_data={}):
        if isinstance(connection_params, str):
            connection_params = dict(url=connection_params)

        url = connection_params["url"]
        if re.search("csv(\\?.*)?$", url):
            df = vaex.from_csv(
                url,
                copy_index=False,
                parse_dates=connection_params.get("parse_dates", []),
            )
        elif re.search("parquet(\\?.*)?$", url):
            df = vaex.open(url)
        elif re.search("hdf5(\\?.*)?$", url):
            df = vaex.open(url)
        else:
            raise "Unsupported file extension"

        return VaexConnection(df)
