import logging
import dash
import dash_design_kit as ddk
import dash_core_components as dcc
import dash_enterprise_auth as auth
import dash_html_components as html
from dash.dependencies import Input, Output, ALL, MATCH, State

import dashboard_engine
from . import elements
from .canvas_config import CanvasConfig
from .data_schema import DataSchema
from .json_schema import ValidationError, validate_and_insert_defaults

import types

from textwrap import dedent


class DashboardEngine:
    """
    DashboardEngine (DBE)

    A Python package which enables Dash app developers
    to easily add dashboards to their Dash apps.

    Arguments:
      - app: A Dash app instance
      - connection_provider: A DBE connection provider
      - element_types: Optional; A list of element classes to register in
        the engine. It defaults to an official set of elements.
      - id: Optional; A unique identifier in order to properly support
            multiple independent instances of DashboardEngine.
    """

    def __init__(self, app, connection_provider, element_types=elements, id="A"):
        """
        Create a DashboardEngine instance
        Arguments:
            app: A Dash app instance
            connection_provider: A DBE connection provider
            element_types: Optional; A list of element classes to register in
                the engine. It defaults to an official set of elements.
            id: Optional; A unique identifier in order to properly support
                multiple independent instances of DashboardEngine.
        """
        self._app = app

        self._id = id

        # Initialize empty
        self._element_types = {}
        self._inputs = []
        self._schemas = {}

        # Register element types
        if isinstance(element_types, types.ModuleType):
            element_types = [getattr(element_types, x) for x in element_types.__all__]
        for element_type in element_types:
            self._register(element_type)

        self._connection_provider = connection_provider
        self._attach_callback()

    def _register(self, cls):
        name = get_element_type_from_class(cls)
        prefix = "handle_"
        prefix_len = len(prefix)
        handlers = [
            func
            for func in dir(cls)
            if func.startswith(prefix) and callable(getattr(cls, func))
        ]
        for handler in handlers:
            prop_name = handler[prefix_len:]
            self._inputs.append(
                {"type": name, "prop": prop_name, "handler": getattr(cls, handler)}
            )

        # TODO: make sure cls has a render method, else give warning
        # TODO: error out if name is already taken
        self._element_types[name] = cls

    def make_state_and_canvas(
        self,
        id,
        connection_params="",
        elements=[],
        arrangement=None,
        editable=True,
    ):
        """
        Create a canvas linked to a new dashboard state

        Arguments:
          - id: A string identifier used to build composite IDs for this linked
            set of components
          - connection_params: A string or a dictionary of parameters
          - elements: A list describing the list of elements
          - arrangement: A dictionary describing the visual arrangement of
            elements

        Returns:
          - A tuple of 2 items:
            1. An instance of DashboardState component
            2. An instance of DashboardCanvas component

            that are linked to one another.
        """
        elements = [_coerce_element(e) for e in elements]
        if arrangement is None:
            config = CanvasConfig()
            for el in elements:
                config.add_card(el)
            arrangement = config.arrangement
        elements = _relayout(elements, arrangement)
        return tuple(
            [
                dashboard_engine.DashboardState(
                    id={"type": "dashboard-state", "id": id, "engine-id": self._id},
                    connection_params=connection_params,
                    elements=elements,
                ),
                dashboard_engine.DashboardCanvas(
                    id={
                        "type": "dashboard_engine_ui",
                        "id": id,
                        "engine-id": self._id,
                        "for": "canvas",
                    },
                    editable=editable,
                    arrangement=arrangement,
                    elements=elements,
                ),
            ]
        )

    def make_state_and_components(self, id, connection_params="", elements=[]):
        """
        Create a set of components linked to a new dashboard state

        Arguments:
          - id: A string identifier used to build composite IDs for this linked
            set of components.
          - connection_params: A string or a dictionary of parameters
          - elements: An list describing the list of elements

        Returns:
          - A tuple of 2 items:
            1. An instance of DashboardState component
            2. A tuple of Dash components

            that are linked to one another.
        """
        elements = [_coerce_element(e) for e in elements]
        return (
            dashboard_engine.DashboardState(
                id={"type": "dashboard-state", "id": id, "engine-id": self._id},
                connection_params=connection_params,
                elements=elements,
            ),
            tuple(
                [
                    html.Div(
                        id={
                            "type": "engine-element",
                            "id": id,
                            "index": index,
                            "engine-id": self._id,
                        },
                    )
                    for index, el in enumerate(elements)
                ]
            ),
        )

    def _attach_callback(self):
        ############
        # Pattern-matching callbacks for vanilla Dash
        ############
        pmc_state = {"type": "dashboard-state", "id": MATCH, "engine-id": self._id}
        pmc_elements = {
            "type": "engine-element",
            "id": MATCH,
            "index": ALL,
            "engine-id": self._id,
        }

        # Generate children
        def generate_children(connection_params, elements):
            output_list = dash.callback_context.outputs_list[0]

            # Get list of elements on page
            indices = [output["id"]["index"] for output in output_list]

            # Get id of the set of components
            id = output_list[0]["id"]["id"]

            children = self._generate_dashboard()(connection_params, elements)[0]
            return [
                [
                    html.Div(
                        id={
                            "type": "engine-element",
                            "id": id,
                            "index": i,
                            "engine-id": self._id,
                        },
                        children=children[i],
                    )
                    for i in indices
                ]
            ]

        self._app.callback(
            [Output(pmc_elements, "children")],
            [Input(pmc_state, "connection_params"), Input(pmc_state, "elements")],
        )(generate_children)

        ############
        # Pattern-matching callbacks for RGL + editor
        ############
        pmc_ui = {
            "type": "dashboard_engine_ui",
            "id": MATCH,
            "for": ALL,
            "engine-id": self._id,
        }

        # Editor callback
        def generate_editor_spec(connection_params):
            return [self._generate_editor_spec()(connection_params)]

        self._app.callback(
            Output(pmc_ui, "editor_spec"), [Input(pmc_state, "connection_params")]
        )(generate_editor_spec)

        # Main callback, generating children for canvas
        self._app.callback(
            Output(pmc_ui, "children"),
            [Input(pmc_state, "connection_params"), Input(pmc_state, "elements")],
        )(self._generate_dashboard())

        # UI interaction callback
        inputs = list(
            Input(
                {
                    "id": MATCH,
                    "index": ALL,
                    "type": input["type"],
                    "engine-id": self._id,
                },
                input["prop"],
            )
            for input in self._inputs
        )
        inputs.append(Input(pmc_ui, "elements"))
        inputs.append(Input(pmc_ui, "arrangement"))

        self._app.callback(
            [Output(pmc_state, "elements"), Output(pmc_ui, "elements")],
            inputs,
            [State(pmc_state, "elements"), State(pmc_state, "connection_params")],
        )(self._ui_interaction())

    def _generate_editor_spec(self):
        def generate(connection_params):
            # Generate JSON schemas for the editor
            connection = self._connection_provider.get_connection(
                connection_params, auth.get_user_data()
            )
            data_schema = connection.get_data_schema()

            element_schemas = {}
            element_types = []
            element_labels = []
            for i, cls in enumerate(self._element_types.items()):
                type = cls[0]
                cls = cls[1]
                schema_generator = getattr(cls, "schema", None)
                if callable(schema_generator):
                    element_schemas[type] = schema_generator(
                        DataSchema(data_schema, connection)
                    )
                    if hasattr(cls, "label"):
                        element_types.append(type)
                        element_labels.append(cls.label)

            schema = {
                "element_types": {
                    "type": "string",
                    "title": "Element type",
                    "enum": element_types,
                    "enumNames": element_labels,
                },
                "element_schemas": element_schemas,
                "data_schema": data_schema,
                "connection_params": connection_params,
            }

            return schema

        return generate

    def _generate_dashboard(self):
        def filter(connection_params, elements):
            correlation_id = dash.callback_context.inputs_list[0]["id"]["id"]

            # Generate specifications for validation
            editor_spec = self._generate_editor_spec()(connection_params)
            _validate_elements_and_insert_defaults(editor_spec, elements)

            # Build selection queries
            selection_queries = []
            for element in elements:
                element_type = element.get("type", "_blank")
                if element_type == "_blank" or element_has_error(element):
                    selection_queries.append(None)
                    continue

                cls = self._element_types[element_type]
                selection_query_generator = getattr(cls, "selection_query", None)
                selection_query = None
                if callable(selection_query_generator):
                    selection_query = selection_query_generator(element)
                    if selection_query and selection_query.is_nop():
                        selection_query = None
                selection_queries.append(selection_query)

            # Load data
            connection = self._connection_provider.get_connection(
                connection_params, auth.get_user_data()
            )
            query_results = connection.query(selection_queries)

            # Build views
            views = []
            for (i, element) in enumerate(elements):
                if element.get("type", "_blank") == "_blank":
                    current_view = new_card()
                elif element_has_error(element):
                    if "is a required property" in element["_error"].get("message", ""):
                        element_label = ""
                        for e_type, e_label in zip(
                            editor_spec["element_types"]["enum"],
                            editor_spec["element_types"]["enumNames"],
                        ):
                            if e_type == element["type"]:
                                element_label = e_label
                        current_view = error_card(
                            error_label="Required Field Missing",
                            element_label=element_label,
                            msg=dedent(
                                """
                            The {} field is missing.\n
                            Required fields are identified with a star (*****)
                            in the editor.
                            """
                            ).format("**{}**".format(element["_error"].get("title"))),
                            icon_name="tasks",
                        )
                    else:
                        current_view = error_card(
                            "Schema validation error",
                            element["_error"].get("message", ""),
                        )
                else:
                    id = {
                        "id": correlation_id,
                        "index": i,
                        "type": element["type"],
                        "engine-id": self._id,
                    }
                    try:
                        current_view = self._element_types[element["type"]].render(
                            id,
                            element,
                            query_results[i],
                            # TODO: reconsider/evaluate placeholder 'opts' dict argument
                            # for API expansion
                            {},
                            DataSchema(editor_spec["data_schema"], connection),
                        )
                    except Exception as e:  # noqa: E722
                        logging.exception(e)
                        current_view = error_card("Render error", str(e))

                views.append(current_view)

            return [views]

        return filter

    def _ui_interaction(self):
        inputs = self._inputs

        def handle(*argv):
            ctx = dash.callback_context

            data_elements = argv[-2]
            editor_elements_input = ctx.inputs_list[-2]
            editor_arrangement_input = ctx.inputs_list[-1]

            # Retrieve connection_params
            connection_params = argv[-1]

            # Retrieve elements from editor or fallback
            if editor_elements_input:
                elements = editor_elements_input[0]["value"]
            else:
                elements = data_elements

            # Get data_schema
            connection = self._connection_provider.get_connection(
                connection_params, auth.get_user_data()
            )
            data_schema = DataSchema(connection.get_data_schema(), connection)

            # TODO: skip inputs that haven't been triggered

            # Generate specifications to insert defaults
            editor_spec = self._generate_editor_spec()(connection_params)
            _validate_elements_and_insert_defaults(editor_spec, elements)

            # Call element's callbacks
            # We use ctx.inputs_list here because it is already parsed
            for input_index, input_list in enumerate(ctx.inputs_list[:-2]):
                for input in input_list:
                    element_index = input["id"]["index"]
                    element = elements[element_index]
                    if (
                        # the element has no error
                        not element_has_error(element)
                        # the input was triggered
                        and "value" in input
                        # and types are the same (see issue #434)
                        and element["type"] == input["id"]["type"]
                    ):
                        inputs[input_index]["handler"](
                            input["value"], elements, element_index, data_schema
                        )

            # Handle layout changes
            if editor_arrangement_input:
                arrangement = editor_arrangement_input[0]["value"]
                elements = _relayout(elements, arrangement)

            if not ctx.outputs_list[1]:
                return [elements, []]
            else:
                return [elements, [elements]]

        return handle


def get_element_type_from_class(cls):
    return ".".join(cls.__module__.split(".")[:-1] + [cls.__name__])


def _coerce_element(element):
    if isinstance(element, dict):
        return element
    else:
        return dict(type=get_element_type_from_class(type(element)), **element._config)


def _relayout(elements, arrangement):
    grid = arrangement.setdefault("grid", {})
    cards = grid.setdefault("lg", [])

    # Collect children index from cards
    children_index = []
    for card in cards:
        card_children = card.setdefault("children", [])
        for i in card_children:
            children_index.append(i)

    # Pad elements to desired length
    try:
        desired_length = max(children_index) + 1
    except ValueError:
        desired_length = 0

    while len(elements) < desired_length:
        elements.append(dict(type="_blank"))

    # Turn invisible elements to new
    for (i, element) in enumerate(elements):
        if i not in children_index:
            elements[i] = dict(type="_blank")

    for (i, card) in enumerate(cards):
        card_children = card.setdefault("children", [])

        for children_index in card["children"]:
            if (
                elements[children_index] is None
                or elements[children_index].get("type", "_blank") == "_blank"
            ):
                elements[children_index] = dict(type="_blank")

    return elements


def _validate_elements_and_insert_defaults(editor_spec, elements):
    # Validate elements' schema and provide defaults
    for element in elements:
        if element.get("type", "_blank") == "_blank":
            continue
        try:
            validate_and_insert_defaults(
                editor_spec["element_schemas"][element["type"]], element
            )
            element.pop("_error", None)
        except KeyError:
            element["_error"] = {
                "message": "Invalid component type",
                "type": type(KeyError).__name__,
            }
        except ValidationError as err:
            key = next(
                k for k in err.validator_value if "'{}' ".format(k) in err.message
            )
            element["_error"] = {
                "message": err.message,
                "type": type(err).__name__,
                "title": err.schema["properties"].get(key, {}).get("title", None),
            }


def element_has_error(element):
    return element.get("_error", False) is not False


def error_card(
    error_label=None, msg=None, element_label=None, icon_name="exclamation-circle"
):

    title = "{} {}".format(element_label or "", error_label or "").strip()

    children = [
        ddk.CardHeader(
            ddk.Icon(icon_name=icon_name),
            title=title if len(title) else None,
            style={"fontSize": "20px"},
        )
    ]

    if msg is not None:
        children.append(html.Div(dcc.Markdown(msg), style={"fontSize": "16px"}))

    return ddk.Card(
        className="placeholder error-card",
        style={"padding": 0},
        type="flat",
        children=children,
    )


def new_card():
    return html.Div(
        className="placeholder",
        children=[
            ddk.Icon(icon_name="tasks"),
            html.P(
                "Element type unspecified",
                style={"font-size": "20px", "text-align": "center"},
            ),
        ],
    )
