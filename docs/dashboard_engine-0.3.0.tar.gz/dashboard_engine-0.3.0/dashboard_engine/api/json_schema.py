from jsonschema import ValidationError, Draft7Validator
from fastjsonschema import validate, JsonSchemaException


def validate_and_insert_defaults(schema, instance):
    if "jsonSchema" in schema:
        schema = schema["jsonSchema"]
    try:
        instance = validate(schema, instance)
    except JsonSchemaException:
        Draft7Validator(schema).validate(instance)


__all__ = ["validate_and_insert_defaults", "ValidationError"]
