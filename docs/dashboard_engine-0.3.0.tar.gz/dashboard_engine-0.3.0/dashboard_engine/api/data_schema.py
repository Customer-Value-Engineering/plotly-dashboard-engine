DATE_TYPES = ["datetime64[ns]"]
NUMERIC_TYPES = [
    "uint8",
    "uint16",
    "uint32",
    "uint64",
    "int8",
    "int16",
    "int32",
    "int64",
    "float32",
    "float64",
]


class DataSchema:
    def __init__(self, data_schema, connection):
        self._data_schema = data_schema
        self._connection = connection

    def all(self):
        return self._exclude([])

    def numeric(self):
        return self.include_types(NUMERIC_TYPES)

    def dates(self):
        return self.include_types(DATE_TYPES)

    def non_numeric(self):
        return self._exclude(self.numeric())

    def discrete(self):
        return self.exclude_types(NUMERIC_TYPES + DATE_TYPES)

    def include_types(self, types):
        return [
            col
            for col, meta in self._data_schema.items()
            if meta.get("dtype", None) in types
        ]

    def exclude_types(self, types):
        return self._exclude(self.include_types(types))

    def _exclude(self, to_exclude):
        return [col for col in self._data_schema if col not in to_exclude]

    def low_cardinality(self):
        return self.cardinality_below(500)

    def cardinality_below(self, max_cardinality):
        return [
            col
            for col, meta in self._data_schema.items()
            if meta.get("cardinality", 0) < max_cardinality
        ]

    def first_value(self, col):
        if self._connection is None:
            return
        return self._connection.order_for_category(col)[0]

    def is_discrete(self, col):
        return not self.is_continuous(col)

    def is_continuous(self, col):
        return self._data_schema[col]["dtype"] in NUMERIC_TYPES + DATE_TYPES
