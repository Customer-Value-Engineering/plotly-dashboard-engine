class CanvasConfig:
    """
    A helper class to configure a Canvas element.

    The canvas is a 12 columns grid that support multiple cards.
    Each card can contain multiple DBE elements.
    """

    def __init__(self):
        """Initialize CanvasConfig"""
        self._options = dict()
        self._cards = []
        self._elements = []
        self._cols = 12

    def add_card(self, elements, x=0, y=0, w=4, h=4):
        """
        Method to add a card into the canvas

        Arguments:
          - elements (list): the list of DBE elements the card contains
          - x (int): The horizontal position of the card (from 0 to 11)
          - y (int): The vertical position of the card
          - w (int): The card's width in units of column (max 12)
          - h (int): The card's height in units of row
        """
        if not isinstance(elements, list):
            elements = [elements]

        children = []
        for element in elements:
            children.append(len(self._elements))
            self._elements.append(element)

        # must be in valid state to begin with
        assert "x" not in _grid_to_string(_grid(self._cards), self._cols)
        w = max(1, min(self._cols, w))
        x = max(0, min(x, self._cols - w))
        h = max(1, h)
        y = max(0, y)
        while "x" in _grid_to_string(
            _grid(self._cards + [(x, y, w, h, children)]), self._cols
        ):
            x += 1
            if x >= self._cols:
                x = 0
                y += 1

        self._cards.append((x, y, w, h, children))
        return self

    def __repr__(self):
        return _grid_to_string(_grid(self._cards), self._cols)

    @property
    def elements(self):
        """
        Returns all elements in the Canvas

        Returns:
          - A list of elements
        """
        return self._elements

    @property
    def arrangement(self):
        """
        Returns a description of the Canvas arrangement

        Returns:
          - A dict describing the current Canvas arrangement
        """
        return dict(
            grid=dict(
                lg=[
                    dict(i=str(i), x=x, y=y, w=w, h=h, children=children)
                    for i, (x, y, w, h, children) in enumerate(self._cards)
                ]
            ),
            **self._options,
        )


def _grid_to_string(grid, cols):
    result = ""
    for row in grid:
        row_result = ""
        for i, cell in enumerate(row):
            if cell is None:
                row_result += " ."
            elif isinstance(cell, list) or i >= cols:
                row_result += " x"
            else:
                row_result += " " + str(cell)
        for i in range(cols - len(row)):
            row_result += " ."
        result += "\n" + row_result
    return result


def _grid(cards):
    grid = []
    for n, (x, y, w, h, _) in enumerate(cards):
        while len(grid) < y + h:
            grid.append([])
        for i in range(x, x + w):
            for j in range(y, y + h):
                while len(grid[j]) < i + 1:
                    grid[j].append(None)
                if grid[j][i] is not None:
                    grid[j][i] = [grid[j][i]]
                if isinstance(grid[j][i], list):
                    grid[j][i].append(n)
                else:
                    grid[j][i] = n
    return grid
