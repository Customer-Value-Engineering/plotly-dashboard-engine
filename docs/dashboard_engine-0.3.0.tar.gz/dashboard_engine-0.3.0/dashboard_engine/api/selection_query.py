class SelectionQuery:
    """A data query that can be fulfilled by a connection"""

    def __init__(
        self,
        select=[],
        where=[],
        local_where=[],
        order_by=[],
        group_by=[],
        limit=-1,
        offset=0,
        where_mask_key=None,
    ):
        """Create an instance of SelectionQuery

        Args:
            select (list of 3-tuples): select data according to tuple's elements:
                1. aggregation method (str): one of "sum", "count", "min", "max",
                    "mean", "std"
                2. column name (str): the name of the column to aggregate
                3. key (str): used to look up column names in the query result
            where (list of dict): list of filter conditions. Conditions can either
                be a "range" or "points". See below for example usage.
            local_where (list of dict): list of filter conditions that are local
                (ie. do not crossfilter).
            order_by (list of tuple): order rows according to tuple's elements:
                1. column name (str): the name of the column used for ordering
                2. order (str): "asc" for ascending or "desc" for descending
            group_by (list of 3-tuples): group data according to tuple's elements:
                1. grouping method (str): one of "none"
                2. column name (str): the name of the column on which to group
                3. key (str): used to look up column names in the query result
            limit (int): number of rows to return. Defaults to -1 for an
                unlimited number of rows.
            offset (int): number of rows to skip before beginning to return the rows.
                Default to 0.
            where_mask_key (str): key for column which will contain a boolean mask
                representing which rows of the data frame match the where clause of
                the SelectionQuery

        Example usage:

        # select and where "points"
        s = SelectionQuery(
            select=[("sum", "pop")],
            where=[
                {"type": "points", "column": "continent", "values": ["Oceania"]}
            ],
        )

        # select and where "range"
        s = SelectionQuery(
            select=[("sum", "pop")],
            where=[
                {"type": "range", "column": "lifeExp", "bounds": [65, 70]},
                {"type": "range", "column": "gdpPercap", "bounds": [15000, 20000]},
            ],
        )

        # group by
        s = SelectionQuery(
            select=[("sum", "pop")],
            group_by=[("none", "continent")],
        )

        # order by
        s = SelectionQuery(
            group_by=[("none", "country")],
            order_by=[("country", "desc")]
        )

        # limit/offset
        s = SelectionQuery(
            group_by=[("none", "country")],
            limit=10,
            offset=50
        )
        """
        self._group_by = []
        self._select = []
        self._keys = []
        for gb in group_by:
            self._add_col(gb, "group_by")
        for s in select:
            self._add_col(s, "select")
        self.where = where
        self.local_where = local_where
        self.limit = limit
        self.order_by = order_by
        self.offset = offset
        self.where_mask_key = where_mask_key

    def _add_col(self, col, col_type):
        if len(col) != 3:
            raise ValueError("%s value lengths should all be 3" % col_type)
        key = col[2]
        if key in self._keys:
            raise ValueError("Key '%s' already used" % key)
        self._keys.append(key)
        if col_type == "select":
            self._select.append(col)
        else:
            self._group_by.append(col)

    @property
    def group_by(self):
        return self._group_by

    @property
    def select(self):
        return self._select

    def is_nop(self):
        return (
            len(self.where) == 0 and len(self._group_by) == 0 and len(self._select) == 0
        )

    def __repr__(self):
        items = ("\t%s=%r" % (k, v) for k, v in self.__dict__.items())
        return "%s(\n {%s}\n)" % (self.__class__.__name__, ",\n".join(items))


class SelectionQueryResult:
    """The result of a data query that can be fulfilled by a connection"""

    def __init__(
        self,
        element_df,
        key_to_label,
        order_for_category,
        colormap_for_category,
    ):
        """Construct a SelectionQueryResult

        Args:
            element_df (Pandas DataFrame): the result of the corresponding
                SelectionQuery
            key_to_label (dict): mapping of keys from SelectionQuery to columns
                in data frame
            order_for_category (function): function returning stable order of
                categorical values for this dataset
            colormap_for_category (function): function returning stable color
                mapping for categorical values for this dataset
        """

        self._df = element_df
        self._key_to_label = key_to_label
        self.order_for_category = order_for_category
        self.colormap_for_category = colormap_for_category

    @property
    def df(self):
        if self._df is None:
            return None
        df = self._df
        for key, label in self._key_to_label.items():
            if label not in df.columns:
                # a previous key already renamed this label
                # need to get a copy of the original column
                df[key] = self._df[label]
            else:
                df = df.rename({label: key}, axis=1, copy=False)
        return df

    def is_empty(self):
        return self.df is None or len(self.df) == 0

    def _is_categorical(self, cat):  # lifted from PX
        if self._df is None or cat is None or cat not in self._df.columns:
            return False
        return self._df[cat].dtype.kind not in "ifc"

    def make_category_orders(self, cats):
        return {
            key: self.order_for_category(cat)
            for key, cat in cats.items()
            if self._is_categorical(cat)
        }

    def make_color_map(self, cat):
        return self.colormap_for_category(cat) if self._is_categorical(cat) else None
