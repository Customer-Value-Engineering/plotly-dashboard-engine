import pandas as pd
import json
import re
import numpy as np

from functools import reduce
from operator import and_
from .selection_query import SelectionQueryResult


def aggregate(df, select, group_by):
    key_to_label = {}
    grouped_cols = []
    aggregated_cols = {}

    # processing for topN, numerical and date binning should go here
    for groupfunc, column, key in group_by:
        label = column
        key_to_label[key] = label
        if column not in grouped_cols:
            grouped_cols.append(column)

    # new aggregators like count-unique, weighted-mean etc should go here
    for aggfunc, column, key in select:
        label = "%s_%s" % (aggfunc, column)
        key_to_label[key] = label
        if label not in aggregated_cols:
            if aggfunc == "count":
                aggfunc = "size"  # count should count even non-null!
            aggregated_cols[label] = (column, aggfunc)

    if df.size == 0:
        for label in aggregated_cols:
            df[label] = ""
        return df, key_to_label

    if len(aggregated_cols) == 0:
        if len(grouped_cols) == 0:
            raise ValueError("nothing to aggregate!")
        result = df[grouped_cols].drop_duplicates()
    else:
        if grouped_cols:
            result = df.groupby(grouped_cols).agg(**aggregated_cols).reset_index()
        else:
            result = (
                df.agg(**aggregated_cols)  # output != groupby().agg()
                .melt(ignore_index=False)  # one row per agg per column
                .drop(["variable"], axis=1)  # drop the dummy column
                .dropna()  # drop the unused agg/column combos
                .T  # transpose
            )
    return result, key_to_label


def dataframe_slice(df, offset, limit):
    if limit != -1 or offset != 0:
        if limit == -1:
            to = None
        else:
            to = offset + limit
        df = df[offset:to]
    return df


def compute_mask(df, where):
    # Compute masks using where statements
    mask = np.full(len(df), True)
    mask_all = np.full(len(df), False)

    for selection in where:
        if selection:
            col = selection["column"]
            if selection["type"] == "range":
                range = selection["bounds"]
                if None not in range:
                    range.sort()
                if range[0] is not None:
                    mask &= df[col] >= range[0]
                if range[1] is not None:
                    mask &= df[col] <= range[1]

            if selection["type"] == "points":
                if len(selection["values"]) == 0:
                    continue

                local_mask = np.copy(mask_all)
                for value in selection["values"]:
                    local_mask |= df[col] == value

                mask &= local_mask

    return mask


class DataFrameConnection:
    def __init__(self, df):
        """
        Initialize the connection to a DataFrame

        Arguments:
          - df (DataFrame): Pandas DataFrame
        """
        self._df = df
        self._data_schema = {
            k: {"dtype": str(v), "cardinality": df[k].nunique()}
            for k, v in df.dtypes.items()
        }

        self._order_cache = {}
        self._colormap_cache = {}

    def get_data_schema(self):
        """
        Returns metadata about the underlying data_schema

        Returns:
        A dict mapping columns names to a dict containing metadata.
        For example:

        ```sh
        >>> connection.get_data_schema()
        {
            'country': {'dtype': 'object', 'cardinality': 142}
            'pop': {'dtype': 'float64', 'cardinality': 142}
        }
        ```
        """
        return self._data_schema

    def order_for_category(self, column):
        if column not in self._order_cache:
            # TODO allow full or partial override to be passed in to constructor
            if column is None or column not in self._df:
                return None
            self._order_cache[column] = sorted(self._df[column].unique())
        return self._order_cache[column]

    def colormap_for_category(self, column):
        if column not in self._colormap_cache:
            # TODO allow full or partial override to be passed in to constructor
            if column is None or column not in self._df:
                return None
            self._colormap_cache[column] = {
                c: "var(--colorway-%d)" % (i % 10)
                for i, c in enumerate(self.order_for_category(column))
            }
        return self._colormap_cache[column]


class PandasConnection(DataFrameConnection):
    """
    A Dashboard Engine compatible connection built on top of Panda's DataFramea

    Arguments:
      - df (DataFrame): Pandas DataFrame
    """

    def query(self, selection_queries):
        """
        Perform a data query described by a list of SelectionQuery

        This method is responsible for querying data
        based on the provided list of SelectionQuery object.
        For each SelectionQuery provided in the list,
        a SelectionQueryResult is returned which contains data filtered based
        on every other SelectionQuery except its own.

        Typical usage example:

        ```py
        result = connection.query(
            [
                SelectionQuery(
                    where=[
                    {"type": "range", "column": "lifeExp", "bounds": [65, 70]},
                    {"type": "range", "column": "gdpPercap", "bounds": [15000, 20000]},
                    ],
                    group_by=[("none", "country")]
                ),
                SelectionQuery(group_by=[("none", "country")]), # select all
            ]
        )
        ```

        Arguments:
          - selection_queries (list of SelectionQuery):

        Returns:
          - list of SelectionQueryResult
        """
        df = self._df

        masks = [
            compute_mask(df, selection_query.where)
            if selection_query is not None
            else None
            for selection_query in selection_queries
        ]
        local_masks = [
            compute_mask(df, selection_query.local_where)
            if selection_query is not None
            else None
            for selection_query in selection_queries
        ]

        dfs = []
        mask_nothing = np.full(len(df), True)
        empty_result = SelectionQueryResult(
            None,
            {},
            self.order_for_category,
            self.colormap_for_category,
        )
        for i, selection_query in enumerate(selection_queries):
            if selection_query is None or (
                len(selection_query.select) == 0 and len(selection_query.group_by) == 0
            ):
                dfs.append(empty_result)
                continue

            # Crossfilter
            mask = reduce(
                and_,
                [m for nth, m in enumerate(masks) if nth != i and m is not None],
                mask_nothing,
            )
            working_df = df.copy(deep=False)
            extra_group_by = []
            if selection_query.where_mask_key:
                working_df["dbe_mask__"] = masks[i]
                extra_group_by = [
                    ("none", "dbe_mask__", selection_query.where_mask_key)
                ]
            element_df = working_df[mask & local_masks[i]]
            if len(element_df) == 0:
                dfs.append(empty_result)
                continue

            # Group by
            element_df, key_to_label = aggregate(
                element_df,
                selection_query.select,
                selection_query.group_by + extra_group_by,
            )

            # Order_by
            if len(selection_query.order_by):
                # TODO: support multi columns sorting instead of only one
                element_df = element_df.sort_values(
                    key_to_label[selection_query.order_by[0][0]],
                    ascending=selection_query.order_by[0][1] == "asc",
                    inplace=False,
                )

            element_df = dataframe_slice(
                element_df, selection_query.offset, selection_query.limit
            )

            dfs.append(
                SelectionQueryResult(
                    element_df,
                    key_to_label,
                    self.order_for_category,
                    self.colormap_for_category,
                )
            )

        return dfs


class DataFrameConnectionProvider:
    """
    Connection provider to Pandas DataFrame

    Arguments:
      - dfs (DataFrame or dict of str: DataFrame): a single DataFrame or
        a mapping of names to DataFrames
    """

    def __init__(self, dfs):
        """
        Initialize a PandasConnectionProvider with one or a collection of DataFrames

        Arguments:
            dfs (DataFrame or dict of str: DataFrame): a single DataFrame or
                a mapping of names to DataFrames
        """
        if isinstance(dfs, dict):
            self._dfs = {k: self._cls(dfs[k]) for k in dfs}
            self._df = None
        else:
            self._df = self._cls(dfs)
            self._dfs = None

    def get_connection(self, connection_params, user_data={}):
        # TODO: elaborate/fill in docstring
        """
        Retrieves a `PandasConnection` instance.

        Returns:
        A `PandasConnection`.
        """
        return self._df if self._df else self._dfs[connection_params]


class PandasConnectionProvider(DataFrameConnectionProvider):
    _cls = PandasConnection


class CachingConnectionProvider:
    """Superclass providing connection caching"""

    def __init__(self):
        self._connection_cache = dict()

    def get_connection(self, connection_params, user_data={}):
        # TODO: elaborate/fill in docstring
        """
        Retreives a cached connection.

        Returns:
        A cached connection.
        """
        connection_params_json = json.dumps(connection_params)
        if connection_params_json not in self._connection_cache:
            connection = self._get_uncached_connection(connection_params)
            self._connection_cache[connection_params_json] = connection
        return self._connection_cache[connection_params_json]


class FileConnectionProvider(CachingConnectionProvider):
    """
    Connection provider to data stored in a file

    If `connection_params` is a string, it is interpreted as a filepath.
    If it is a dict, its `url` value is interpreted as a filepath.
    Optionally, the key `parse_dates` can contain a list of column names
    which should be parsed as date.

    The file must have one of the following supported extension:
      - csv(.gz)
      - parquet(.gz)
    """

    def _get_uncached_connection(self, connection_params):
        if isinstance(connection_params, str):
            connection_params = dict(url=connection_params)

        url = connection_params["url"]
        if re.search("csv(.gz)?$", url):
            df = pd.read_csv(url, low_memory=False)
        elif re.search("parquet(.gz)?$", url):
            df = pd.read_parquet(url)
        else:
            raise "Unsupported file extension"

        for col in connection_params.get("parse_dates", []):
            df[col] = pd.to_datetime(df[col], infer_datetime_format=True)
        for col, dtype in connection_params.get("dtype", {}).items():
            df[col] = df[col].astype(dtype)
        return PandasConnection(df)
