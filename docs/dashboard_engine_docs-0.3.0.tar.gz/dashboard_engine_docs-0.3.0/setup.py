import json
from setuptools import setup

"""
Mimic the main package's descriptors, minus the
package name and description. This way, the
package and docs package versions are sync'd
no matter what, even if one package has changes
and the other does not. That way, we always know
a docs version accurately documents a release version
"""

with open("package.json") as f:
    package = json.load(f)

package_name = package["name"].replace(" ", "_").replace("-", "_")

docs_package_name = "{package_name}_docs".format(package_name=package_name)

description = "Docs for the {package_name} library.\n{package_description}".format(
    package_name=package_name.replace("_", "-"),
    package_description=package.get("description", package_name),
)

print(docs_package_name)

setup(
    name=docs_package_name,
    version=package["version"],
    author=package["author"],
    packages=[
        "dashboard_engine_docs",
        "dashboard_engine_docs/chapters",
        "dashboard_engine_docs/components",
    ],
    include_package_data=True,
    license=package["license"],
    description=description,
    install_requires=[
        "dash_dangerously_set_inner_html",
        "plotly==4.14.*",  # 4.14.3 is the minimum
    ],
    classifiers=["Framework :: Dash"],
)
