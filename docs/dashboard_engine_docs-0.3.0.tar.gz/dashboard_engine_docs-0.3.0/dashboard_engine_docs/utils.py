import dash
import dash_html_components as html
import dash_core_components as dcc
import dash_design_kit as ddk

import inspect
import os
import re
import textwrap

if os.environ.get("DASH_APP_LOCATION", "") != "ABSOLUTE":
    from .server import app
else:
    print("--------> DBE UTILS")
    from server import app


def component_doc(component, prefix="", prefix_signature="", doc_init=False):
    args_len = len(inspect.signature(component).parameters.items())
    left_paren_replacement = "(\n    " if args_len > 1 else "("
    right_paren_replacement = "\n)" if args_len > 1 else ")"

    if doc_init:
        doc = getattr(component.__init__, "__doc__", "")
    else:
        doc = getattr(component, "__doc__", "")

    sig = inspect.signature(component)
    sig = sig.replace(
        parameters=[
            param.replace(
                default=inspect.Parameter.empty, annotation=["{all element classes}"]
            )
            if param.name == "element_types"
            else param
            for param in sig.parameters.values()
        ]
    )

    return html.Div(
        [
            html.A(
                className="anchor",
                href="#{}".format(component.__name__),
                children=html.H2(
                    html.Code("{}{}".format(prefix, component.__name__)),
                    id=component.__name__,
                    className="docs-article",
                ),
            ),
            html.Div(
                className="docs-article",
                children=dcc.Markdown(
                    "```py\n{}{}{}\n```".format(
                        prefix_signature,
                        component.__name__,
                        str(sig)
                        .replace(",", ",\n   ")
                        .replace("(", left_paren_replacement)
                        .replace(")", right_paren_replacement)
                        .replace("    self,\n", "")
                        .replace("\n    self\n", "")
                        .replace("(self)", "()"),
                    )
                ),
            ),
            dcc.Markdown(doc, className="docs-article"),
            html.Hr(className="docs-article"),
        ]
    )


def relpath(path):
    """
    Prefix relative URLs with the Dash app name in case that
    the app is deployed on DDS.
    """
    if "DBE_URL_PREFIX" in os.environ:
        if path.startswith("/assets"):
            return "{}{}".format("/Docs", path)
        if path.startswith("/Docs"):
            return path
        return "{}{}{}".format("/Docs", os.environ["DBE_URL_PREFIX"], path)
    elif "DASH_APP_NAME" in os.environ:
        return "/{}{}".format(os.environ["DASH_APP_NAME"], path)
    return path


def article(children=None, dedent=True, **kwargs):
    # Use relative links in markdown embedded links
    children = re.sub(
        "]\((\/\S*)\)",
        lambda match: "]({})".format(relpath(match.groups()[0])),
        children,
    )
    if dedent:
        children = textwrap.dedent(children)

    return html.Article(dcc.Markdown(children), className="docs-article", **kwargs)


def snake_to_human_case(string):
    return " ".join(x.capitalize() or "_" for x in string.split("_"))


def exception_handler(func):
    def wrapper(path, *args, **kwargs):
        try:
            return func(path, *args, **kwargs)
        except Exception as e:
            print(
                "\nError running {}\n{}".format(
                    path,
                    (
                        "======================================"
                        + "======================================"
                    ),
                )
            )
            raise e

    return wrapper


@exception_handler
def load_example(path, replace_ddk_app=True):
    """
    Load a dash app from a file and return the layout as a component.
    Additionally:
    - Provide some simple validation that the example is correct
    - Comment out some commands that would break when "exec"ing the file
    in the context of an existing app.

    This is adapted from dash-docs: https://github.com/plotly/dash-docs/blob/82035954243a5d5bbbbf33c523b08a58b8fac3c0/tutorial/tools.py
    and dash-design-kit: https://github.com/plotly/dash-design-kit/blob/a16fe147a4d8917565ba8dbe468e0f0ee5199e13/dash_design_kit_docs/misc.py#L220
    """
    import dash_html_components as html

    normalized_path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)), "docs_apps", *path.split("/")
    )
    with open(normalized_path, "r") as _f:
        _source = _f.read()
        _example = _source

        # Use the global app assignment
        if "app = dash.Dash" not in _example and "app = CustomDash()" not in _example:
            raise Exception("Didn't declare app")
        _example = _example.replace("app = dash.Dash", "# app = dash.Dash")

        commented_configs = [
            "app.scripts.config.serve_locally",
            "app.css.config.serve_locally",
        ]
        for config in commented_configs:
            _example = _example.replace(config, "# {}".format(config))

        required_imports = [
            "import dash\n",
            "import dash_design_kit as ddk\n",
        ]
        for import_statement in required_imports:
            if import_statement not in _example:
                raise Exception("Didn't '{}'".format(import_statement))

        # return the layout instead of assigning it to the global app
        if "app.layout = " not in _example:
            raise Exception("app.layout not assigned")
        _example = _example.replace("app.layout = ", "layout = ")

        valid_initializations = [
            "layout = ddk.App(show_editor=True, theme=theme, use_mobile_viewport=False, children="
            "layout = ddk.App(show_editor=True, use_mobile_viewport=False, children=",
            "layout = ddk.App(show_editor=True, theme=theme, children=",
            "layout = ddk.App(show_editor=True, children=",
            "layout = ddk.App(theme=theme, children=",
            "layout = ddk.App(",
        ]

        if not any([init in _example for init in valid_initializations]):
            raise Exception('Missing line in example:\n"layout = ddk.App(..."')

        if replace_ddk_app:
            # remove `App` since this is being run in the context of
            # the user guide, which has a global `App`
            for init in valid_initializations:
                _example = _example.replace(init, "layout = html.Div(")

        # Remove the "# Run the server" commands
        if "app.run_server" not in _example:
            raise Exception("app.run_server missing")
        _example = _example.replace(
            "\n    app.run_server", 'print("Running")\n    # app.run_server'
        )

        # Use DDS asset URLs
        _example = _example.replace("/assets/", relpath("/assets/"))

        scope = {"app": app, "html": html}
        exec(_example, scope)

    return {
        "source": _source,
        "layout": scope["layout"],  # layout is a global created from the app
    }


def load_example_string(example_string):
    """
    Pass in a code block, replace a few things, exec it, and
    return a markdown code block and the layout
    """
    exec_example_string = textwrap.dedent(example_string)
    replace_pairs = [
        ["app.layout", "layout"],
        [
            'app.get_asset_url("your-logo.png")',
            "'{}'".format(relpath("/assets/fred-logo-2x.png")),
        ],
        ["ddk.App(theme=ddk_theme, children=[", "html.Div(["],
        ["ddk.App", "html.Div"],
        ["app = dash.Dash(__name__)", ""],
        ['if __name__ == "__main__":\n    app.run_server(debug=True)', ""],
    ]
    for pair in replace_pairs:
        exec_example_string = exec_example_string.replace(pair[0], pair[1])

    scope = {
        "app": app,
        "ddk": ddk,
        "dcc": dcc,
        "html": html,
        "Output": dash.dependencies.Output,
        "Input": dash.dependencies.Input,
        "State": dash.dependencies.State,
    }
    exec(exec_example_string, scope)
    return html.Div(
        [
            html.Div(
                ddk.Card(
                    article(
                        "```{}```".format(textwrap.dedent(example_string)),
                        style={"width": "auto"},
                    ),
                    style={"text-align": "initial"},
                    margin=0,
                    type="flat",
                ),
                className="docs-article",
            ),
            html.Br(),
            html.Div(scope["layout"], style={"text-align": "initial"}),
            html.Br(),
        ],
    )
