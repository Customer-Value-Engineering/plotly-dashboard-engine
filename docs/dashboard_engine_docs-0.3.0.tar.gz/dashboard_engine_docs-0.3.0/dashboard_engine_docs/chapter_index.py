from . import chapters
from . import utils
from .toc import create_toc

import os

URLS = [
    {
        "url": utils.relpath("/"),
        "name": "About & Table of Contents",
        "description": (
            """
            Dash Enterprise Dashboard Engine (DBE) is a Python package which
            enables Dash app developers to easily add dashboards to their apps.
            DBE-powered dashboards are collections of elements, such as charts
            and controls, that are bound to some dataset and automatically
            interact with each other via crossfiltering: selections made in one
            element are reflected in the others. DBE-powered dashboards can be
            made user-editable, so that app users can add, configure and arrange
            elements without needing to modify any app code.
            """
        ),
        # This content is generated from URLS below
    },
    {
        "name": "Overview",
        "chapters": [
            {
                "url": utils.relpath("/introduction"),
                "name": "Introduction",
                "description": ("An overview of Dashboard Engine."),
                "content": chapters.introduction.layout,
                "icon": "info-circle",
            },
            {
                "url": utils.relpath("/installation"),
                "name": "Installation",
                "description": (
                    "Instructions for adding Dashboard Engine to a Dash App."
                ),
                "content": chapters.installation.layout,
                "icon": "tools",
            },
            {
                "url": utils.relpath("/distribution"),
                "name": "The Distribution Bundle",
                "description": (
                    "A description of the Limited Availability distribution bundle."
                ),
                "content": chapters.distribution.layout,
                "icon": "file-archive",
            },
            {
                "name": "Quick Start",
                "url": utils.relpath("/quick-start"),
                "description": (
                    "A walkthrough of the code for a minimal Dash App powered by Dashboard Engine."
                ),
                "content": chapters.quickstart.layout,
                "icon": "key",
            },
        ],
    },
    {
        "name": "Concepts",
        "chapters": [
            {
                "name": "Connecting to Data",
                "url": utils.relpath("/connecting-to-data"),
                "description": ("How data gets into Dashboard Engine classes."),
                "content": chapters.connecting_to_data.layout,
                "icon": "database",
            },
            {
                "name": "Saving and Loading Dashboards",
                "url": utils.relpath("/saving-and-loading"),
                "description": (
                    "Integrating Dashboard Engine with Dash Snapshot Engine."
                ),
                "content": chapters.saving_and_loading.layout,
                "icon": "camera-retro",
            },
            {
                "name": "Elements and Arrangements",
                "url": utils.relpath("/elements"),
                "description": ("The underlying building blocks of dashboards."),
                "content": chapters.elements.layout,
                "icon": "th-large",
            },
            {
                "name": "Engine, States and Canvases",
                "url": utils.relpath("/engines-and-canvases"),
                "description": ("The main Dashboard Engine classes."),
                "content": chapters.engines_and_canvases.layout,
                "icon": "cogs",
            },
        ],
    },
    {
        "name": "Reference",
        "chapters": [
            {
                "name": "API Reference",
                "url": utils.relpath("/reference"),
                "description": ("All Dashboard Engine classes and methods."),
                "content": chapters.reference.layout,
                "icon": "book",
            },
            {
                "name": "Limitations and Tradeoffs",
                "url": utils.relpath("/limitations"),
                "description": ("When to use Dashboard Engine."),
                "content": chapters.limitations.layout,
                "icon": "balance-scale-right",
            },
            {
                "url": utils.relpath("/changelog"),
                "name": "Changelog",
                "description": ("What’s new in this version."),
                "content": chapters.changelog.layout,
                "icon": "newspaper",
            },
            # {
            #    "name": "Frequently Asked Questions",
            #    "url": utils.relpath("/faq"),
            #    "description": ("...and their answers."),
            #    "content": chapters.faq.layout,
            #    "icon": "question-circle",
            # },
        ],
    },
]

URLS[0]["content"] = create_toc(URLS)

URL_TO_CONTENT_MAP = {}
URL_TO_BREADCRUMB_MAP = {}
URL_TO_SIBLINGS_MAP = {}


def create_url_mapping(url_set, adjacent_sections, enumerated_url_set):
    for (i, section) in enumerate(url_set):
        if "url" in section and "content" in section:
            url = (
                section["url"].rstrip("/")
                if not section["url"] == "/"
                else section["url"]
            )
            if "DASH_APP_NAME" in os.environ:
                url = url.replace(
                    "/{}".format(
                        os.environ.get(
                            "DASH_APP_NAME",
                        )
                    ),
                    "",
                )
            if not len(url):
                url = "/"
            URL_TO_CONTENT_MAP[url] = {
                "content": section.get(
                    "content",
                    "Content for {} not defined".format(section["url"].rstrip("/")),
                ),
                "name": section.get("name", None),
                "description": section.get("description", None),
            }
            URL_TO_BREADCRUMB_MAP[url] = section.get("breadcrumb", section["name"])
            URL_TO_SIBLINGS_MAP[url] = {
                "before": {"url": url_set[i - 1]["url"], "name": url_set[i - 1]["name"]}
                if i > 0 and "url" in url_set[i - 1]
                else (adjacent_sections.get("before") if adjacent_sections else None),
                "after": {"url": url_set[i + 1]["url"], "name": url_set[i + 1]["name"]}
                if i < len(url_set) - 1 and "url" in url_set[i + 1]
                else (adjacent_sections.get("after") if adjacent_sections else None),
            }
        if "chapters" in section:

            prev_section = enumerated_url_set.get(i - 1)
            next_section = enumerated_url_set.get(i + 1)

            create_url_mapping(
                section["chapters"],
                {
                    "before": {
                        "url": prev_section.get("chapters")[-1]["url"]
                        if prev_section.get("chapters")
                        else prev_section.get("url"),
                        "name": prev_section.get("chapters")[-1]["name"]
                        if prev_section.get("chapters")
                        else prev_section.get("name"),
                    },
                    "after": {
                        "url": next_section.get("chapters")[0]["url"]
                        if next_section.get("chapters")
                        else next_section.get("url"),
                        "name": next_section.get("chapters")[0]["name"]
                        if next_section.get("chapters")
                        else next_section.get("name"),
                    }
                    if next_section
                    else None,
                },
                enumerated_url_set,
            )


create_url_mapping(URLS, None, dict(list(enumerate(URLS))))
