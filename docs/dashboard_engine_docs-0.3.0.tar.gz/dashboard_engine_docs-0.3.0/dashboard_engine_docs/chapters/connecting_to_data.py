import dash_html_components as html
from .. import utils

layout = html.Div(
    [
        # TODO sample tables in the data frame section
        utils.article(
            """

# Connecting to Data

`DashboardEngine` objects are bound to a single *connection provider*, provided
upon construction, which mediates the link between dashboards created by the
engine and the dataset(s) the connection provider can connect to. A connection
provider is simply an object that exposes a `get_connection(connection_params,
user_data)` function which returns a *connection* object.

In the examples encountered so far, only the built-in `PandasConnectionProvider`
has been used, in conjunction with a single data frame as input. In this
configuration, the connection provider always returns a connection to the same
Pandas data frame. However, it is possible for a connection provider to mediate
connections to different data sets, as controlled by the `connection_params`
argument to `make_state_and_canvas()`. The expected type and contents of
`connection_params` depend on the specific connection provider being used, but
in all cases must be composed of JSON-serializable objects like `dict`s,
`list`s, strings, booleans and numbers. Whenever a dashboard is initially
rendered or updated, or whenever the value of its `connection_params` changes,
the engine requests a connection from the connection provider by calling
`get_connection`, and renders data obtained from the connection.

Here is an example of an app using the built-in `PandasConnectionProvider` with
more than one data frame (by passing in a `dict` of data frames with string
keys) to provide users with the ability to have one canvas that switches between
two datasets. The `connection_params` object in this case is a string which is
expected to be a key in the input `dict`. In this example the datasets have the
same set of columns, so the charts simply update.

Note: in the example below, we use the `elements` argument of
`make_state_and_canvas()` to prepopulate the canvas for demonstration purposes.
This argument will be explained in more detail in the chapter on [Elements and
Arrangements](elements).

"""
        ),
        utils.load_example_string(
            """
import dash
import dash_html_components as html
import dash_core_components as dcc
import dash_design_kit as ddk
import pandas as pd
from dash.dependencies import Input, Output
import dashboard_engine as dbe

app = dash.Dash(__name__)
dfs = dict(
    df1=pd.DataFrame(dict(a=["a", "b", "c", "d"], b=[1, 2, 3, 4])),
    df2=pd.DataFrame(dict(a=["a", "b", "c", "d"], b=[4, 3, 2, 1])),
)
df_keys = list(dfs.keys())
conn_provider = dbe.PandasConnectionProvider(dfs)
engine = dbe.DashboardEngine(app, conn_provider, id="data0")
state, canvas = engine.make_state_and_canvas(
    connection_params=df_keys[0],
    elements=[dbe.elements.Bar(x="a", y="b", color="b")],
    id="sc"
)

app.layout = ddk.App(
    children=html.Div(
        [
            ddk.Card(
                dcc.Dropdown(
                    id="df_switcher",
                    value=df_keys[0],
                    options=[{"label": x, "value": x}
                             for x in df_keys],
                    clearable=False,
                ),
                width=33.3
            ),
            state,
            canvas,
        ]
    ),
)


@app.callback(
    Output(state.id, "connection_params"),
    Input("df_switcher", "value"),
    prevent_initial_call=True,
)
def change_dataset(df_key):
    return df_key


if __name__ == "__main__":
    app.run_server(debug=True)
    """
        ),
        utils.article(
            """
## Built-in `ConnectionProvider` and `Connection` Classes

DBE comes with two built-in connection providers: we have already used
`PandasConnectionProvider` to connect engines to in-memory data frames, but
there is also the `FileConnectionProvider`. The `FileConnectionProvider` accepts
paths or URIs to files as `connection_params`, and will download and process a
file the first time it receives a given `connection_params`, caching it
thereafter.

A connection provider is simply an object that exposes a
`get_connection(connection_params)` function which returns a *connection*
object. At the moment, only one kind of `Connection` object is provided with
DBE: the `PandasConnection` which wraps a Pandas `DataFrame` object. This means
that the primary responsibility of a connection provider today is to construct a
data frame given a set of `connection_params`.

## Custom Connection Providers

Here is an example that shows how to build a simple connection provider to
connect to a time-varying data source. In this contrived example the
time-varying data source is simply a set of random numbers, but this function
can easily be replaced by a database query or API call in a real application. In
the example below the `get_connection` function does not use the value of
`connection_params` so it can take on any value, but a new set of random numbers
will be provided to the engine any time the `connection_params` change.

This example shows how one use of the `state` object that is returned by the
`make_state_and_canvas` method. The `state` object is a component of type
`DashboardState` that allows callbacks to write to an active canvas'
`connection_params`, as well as read the internal state of a `canvas`. In the
app below, the `connection_params` is being updated every 1.5 seconds by a
`dcc.Interval` component, causing the graph to refresh with the newly-provided
random data. In a real application, this approach could be used to show
near-real-time data from a database or API.
    """
        ),
        utils.load_example_string(
            """
import dash
import dash_core_components as dcc
import dash_design_kit as ddk
import pandas as pd
import numpy as np
from dash.dependencies import Input, Output
import dashboard_engine as dbe


class RandomConnectionProvider:
    def get_connection(self, connection_params, user_data):
        # get new data from source, in this case random data
        df = pd.DataFrame(dict(
            a=np.random.rand(100),
            b=np.random.rand(100)
        ))
        return dbe.PandasConnection(df)


app = dash.Dash(__name__)
conn_provider = RandomConnectionProvider()
engine = dbe.DashboardEngine(app, conn_provider, id="data1")

state, canvas = engine.make_state_and_canvas(
    elements=[dbe.elements.Scatter(x="a", y="b", color="b")],
    id="data1_sc"
)

app.layout = ddk.App(
    children=[dcc.Interval(interval=1500, id="interval"), state, canvas]
)


@app.callback(
    Output(state.id, "connection_params"),
    Input("interval", "n_intervals"),
    prevent_initial_call=True,
)
def refresh_dataset(n_intervals):
    return dict(n_intervals=n_intervals)


if __name__ == "__main__":
    app.run_server(debug=True)

    """
        ),
        utils.article(
            """
## Data Frame Considerations

The built-in `PandasConnection` class wraps an in-memory Pandas `DataFrame`
which contains *all* of the data that a given dashboard can display.

### Data Frame Size

All dashboard data is filtered and aggregated within the Dash application
itself, even if the data comes from a remote data store such as a database. For
performance reasons, when using the `PandasConnection` we do not recommend using
Pandas data frames that are bigger than approximately 1 million rows and 20
columns. Custom connection providers can query datasets that are much larger
than this within a remote data store such as a database, but the data frame that
is passed to the `PandasConnection` should respect these limits, meaning that
the connection provider should do its own filtering and/or aggregating upstream
of the connection if the source dataset is too big. Future versions of DBE will
contain additional `Connection` classes that will make use of the filtering and
aggregation capabilities of remote data stores to process larger datasets.

### Data Frame Shape

The dashboard elements provided with DBE all currently assume a connection to a
“long form” or “tidy” dataset where each row corresponds to an observation and
each column corresponds to a variable. As an example of this assumption, the
`Bar` element can be configured to map one column to the X axis along which bars
are drawn, one column to the Y axis along which bars are drawn and one column to
the color with which bars are filled. This means that to enable users to make a
bar chart with seven colors, one per day of week, there must be a column in the
dataset containing the name of the day of the week, rather than the “wide form”
equivalent, which would be one column per day of week.

### Dataset Types

Elements are sensitive to the data type of columns in the data set, for example
the `DateRangePicker` element can only be bound to columns of with a `dtype` of
`datetime64[ns]`, and numerical columns are expected to be of a numerical type
(`int64` or `float64`) rather than strings containing stringified versions of
the equivalent values.

### Aggregations & Binning

Although various built-in elements can *aggregate* data (e.g. count or take the
sum of a column), none of the built-in elements have the capability to *bin*
data, so in order to enable users to make e.g. bar charts of total sales by
month for daily data, a column called “month” containing strings like "01 -
January" or "01 - Feb" (and with a `dtype` of `object`) will need to be added to
the data frame that is passed to the connection, in addition to the date column
which can be of type `datetime64[ns]`.

## Design Considerations for Custom Connection Providers

Connection providers and connections have very different lifecycles. Connection
providers are typically created once per app, globally, and provide connections
to engines "on demand". Connections, on the other hand, are only ever created
during callbacks, and are disposed of once the callback returns. This means that
row-level security, data caching or database connection-pooling techniques can
be implemented in the connection provider, while reusing generic connection
classes like the `PandasConnection`.

When building a dashboard where different users need to see different subsets of
a larger dataset (i.e. one with row-level security), the connection provider's
`get_connection` method is the place where the user-specific data filtering
logic must be implemented. The second parameter of the `get_connection` method
is `user_data`, and is an object provided on a per-call basis containing data
about the user that will see the data from the connection. This data comes from
the  [the `dash-enterprise-auth`
package](https://dash.plotly.com/dash-enterprise/app-authentication) and will
contain different information about the active user, depending on how Dash
Enterprise was configured: it may contain the user's email address or LDAP
Distinguished Name or simply the user's username. These user-specific tokens may
be correlated against columns in the dataset to identify which rows a given user
should have access to.

If building a custom connection provider to connect to a small
(sub-1-million-row) slowly-changing dataset on a remote server, it may make
sense to have the connection provider cache data in memory such that the remote
data store is only queried if the cached data is older than some interval like 5
minutes or an hour or a day. If the remote data store is fairly slow, this
tradeoff between data freshness and app responsiveness could be beneficial.

When connecting to a remote database, there are often limitations to how many
database connections can be opened at once, so it make may sense to implement a
database-connection pool within the provider, to limit the number of
database-connections a given app sets up.
    """
        ),
    ]
)
