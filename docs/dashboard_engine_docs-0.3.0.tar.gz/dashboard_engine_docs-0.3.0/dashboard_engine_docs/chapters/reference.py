import dash
import dashboard_engine as dbe
import dash_html_components as html
import dash_core_components as dcc

import dash_html_components as html
from .. import utils
import inspect

# Indicates the 'example' variable name for an instance of each respective class in the docs
SAMPLE_DOCS_INSTANCES = {
    "DashboardEngine": "engine",
    "PandasConnectionProvider": "connection_provider",
    "FileConnectionProvider": "connection_provider",
    "CachingConnectionProvider": "provider",
    "PandasConnection": "connection",
    "CanvasConfig": "config",
    "DashboardCanvas": "canvas",
    "DashboardState": "state",
}


def get_classes(namespace):
    if namespace.__name__ == "dashboard_engine":
        class_list = SAMPLE_DOCS_INSTANCES.keys()
    else:
        class_list = dir(namespace)

    return [
        getattr(namespace, class_name)
        for class_name in class_list
        if inspect.isclass(getattr(namespace, class_name))
    ]


def get_methods(class_name):
    return [
        getattr(class_name, method)
        for method in dir(class_name)
        # inspect.ismethod refers to bound methods only
        if inspect.isfunction(getattr(class_name, method))
        and not method.startswith("_")
        and getattr(class_name, method).__doc__ is not None
    ]


def get_elements(elements):
    return [html.Div(utils.component_doc(e, "", "dbe.elements.", True)) for e in elements]


def get_class_descriptions(classes):
    class_descriptions = []
    for c in classes:
        try:
            inspect.signature(c)
        except Exception:
            continue

        sample_instance = SAMPLE_DOCS_INSTANCES.get(c.__name__, "instance")

        class_descriptions.append(
            html.Div(
                [
                    html.H1(c.__name__),
                    html.H2("Class Interface"),
                    html.Div(utils.component_doc(c, "", "dbe.")),
                    html.H2("Class Methods") if len(get_methods(c)) > 0 else "",
                    html.Div(
                        [
                            html.H5("Jump to Method"),
                            html.Div(
                                className="docs-article",
                                style={"columnCount": 2},
                                children=[
                                    html.Ul(
                                        [
                                            html.Li(
                                                html.A(
                                                    m.__name__,
                                                    href="#{}".format(m.__name__),
                                                )
                                            )
                                            for m in get_methods(c)
                                        ]
                                    )
                                ],
                            ),
                            html.Br(),
                        ]
                    )
                    if len(get_methods(c)) > 1
                    else "",
                    html.Div(
                        [
                            utils.component_doc(
                                m,
                                "{}.".format(c.__name__),
                                "{instance}.".format(
                                    c.__name__, instance=sample_instance
                                ),
                            )
                            for m in get_methods(c)
                        ]
                    ),
                ]
            )
        )

    return class_descriptions


layout = html.Div(
    [
        html.H1("Reference", id="top"),
        dcc.Markdown(
            """
            The following is a full list of Dashboard Engine
            elements, classes and their respective methods,
            and their available arguments.
            """
        ),
        html.Div(get_class_descriptions(get_classes(dbe))),
        html.H1("Elements"),
        html.H5("Jump to Element"),
        html.Div(
            className="docs-article",
            style={"columnCount": 2},
            children=[
                html.Ul(
                    [
                        html.Li(
                            html.A(
                                e.__name__,
                                href="#{}".format(e.__name__),
                            )
                        )
                        for e in get_classes(dbe.elements)
                    ]
                )
            ],
        ),
        html.Br(),
        html.Div(get_elements(get_classes(dbe.elements))),
    ],
    className="docs-article",
)
