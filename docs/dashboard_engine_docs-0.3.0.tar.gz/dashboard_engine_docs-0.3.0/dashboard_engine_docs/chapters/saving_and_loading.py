import dash_html_components as html
from .. import utils

layout = html.Div(
    [
        utils.article(
            """
# Saving and Loading Dashboards

Dashboard Engine (DBE) enables Dash app developers to put user-editable
canvases, which are regular Dash components of type `DashboardCanvas`, into
their app layouts. Any changes that users make to a canvas in their browser are
ephemeral, meaning that these changes are lost if the user navigates away or
closes their browser tab, unless saved to a database. DBE was designed to
support this by interoperating with *Dash Snapshot Engine* (DSE) which is
another Python library provided with Dash Enterprise. For more information about
Dash Snapshot Engine, including information about how to use Dash Enterprise to
attach a database to an app to store snapshots, please refer to the
documentation within your instance of Dash Enterprise.

Using DSE, a Dash app can save and load the state of any Dash component,
including `DashboardCanvas` components. Here is the code for a simple
application (it's the same as the `editable_app` in the [distribution zip
file](distribution)) which always renders the latest saved snapshot of a canvas,
and has a single button to save a new snapshot.

```python
import dash
import dash_html_components as html
import dash_snapshots
from dash.dependencies import Input, Output, State
import dash_design_kit as ddk
import plotly.express.data as data
import dashboard_engine as dbe
import os

# pattern to configure db for both local dev and prod on Dash Enterprise
os.environ["SNAPSHOT_DATABASE_URL"] = os.environ.get(
    "SNAPSHOT_DATABASE_URL",
    os.environ.get("DATABASE_URL", "sqlite:////tmp/multi_dashboard.db"),
)

app = dash.Dash(__name__)
conn_provider = dbe.PandasConnectionProvider(data.gapminder())
engine = dbe.DashboardEngine(app, conn_provider)
snap = dash_snapshots.DashSnapshots(app)


def layout_with_latest_snapshot():
    try:  # here is where we load the dashboard: it's the latest snapshot
        state_and_canvas = snap.snapshot_get(snap.snapshot_list()[0])
    except Exception:  # no saved snapshots yet
        state_and_canvas = engine.make_state_and_canvas(id="sc")

    return ddk.App(
        children=[
            html.Button("Save", id="save"),
            html.Div(children=state_and_canvas, id="state_and_canvas"),
        ]
    )

@app.callback(
    Output("state_and_canvas", "children"),
    Input("save", "n_clicks"),
    State("state_and_canvas", "children"),
    prevent_initial_call=True,
)
def lifecycle(n_save_clicks, state_and_canvas):
    # here is where we save the dashboard
    snap.snapshot_save(state_and_canvas)
    return state_and_canvas

# when app.layout is a function, that function is called on page-load
app.layout = layout_with_latest_snapshot

if __name__ == "__main__":
    app.run_server(debug=True)
```

## Authenticated Saving and Loading Patterns

The example app above is the minimal example of saving and loading a DBE-powered
dashboard, and is quite simplistic: anyone accessing the app can in effect
modify the app for all subsequent users. It is possible to use this app as a
starting point to build a more complex app where only certain users have access
to the save button. This can be done in conjunction with [the
`dash-enterprise-auth`
package](https://dash.plotly.com/dash-enterprise/app-authentication).


An even more advanced pattern for using DBE and DSE together is to build an app
that lets users create and save multiple independent views. This is what the
`multi_dashboard` sample app in the [distribution zip file](distribution)
demonstrates. In that app, any user can create a dashboard, and any user can
access, modify, fork or delete any dashboard, just to keep the code for the
sample app simple enough to demonstrate the concept of a dashboard's lifecycle,
but is likely too simple for a real application. This app can be used as base
from which to build more complex workflows that control which users can perform
which actions on which dashboards, again in conjunction with [the
`dash-enterprise-auth`
package](https://dash.plotly.com/dash-enterprise/app-authentication).
"""
        )
    ]
)
