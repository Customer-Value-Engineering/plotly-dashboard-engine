import dash_html_components as html
from .. import utils

layout = html.Div(
    [
        # TODO preloading selections?
        utils.article(
            """
# Elements and Arrangements

In previous examples, we have seen that the `make_state_and_canvas()` function
accepts an optional `elements` argument that enables a developer to pre-populate
the contents of the canvas. Passing in a `dbe.elements.Bar` instance to
`elements` is the Python equivalent of a canvas user adding a bar chart to the
canvas with their mouse. DBE comes with a number of built-in element types,
which are all demonstrated here:

    """
        ),
        utils.load_example_string(
            """
import dash
import dash_design_kit as ddk
import plotly.express.data as data
import pandas as pd
import dashboard_engine as dbe


app = dash.Dash(__name__)
df = data.gapminder()
# need a date column for DateRangePicker
df["year_date"] = pd.to_datetime(df["year"].astype(str)+"-01-01")
conn_provider = dbe.PandasConnectionProvider(df)
engine = dbe.DashboardEngine(app, conn_provider, id="ec0")

state, canvas = engine.make_state_and_canvas(
    id="sc",
    elements=[
        dbe.elements.Bar(x="continent", y="pop", color="continent"),
        dbe.elements.Scatter(x="gdpPercap", y="lifeExp", color="continent"),
        dbe.elements.Line(x="year", y="pop", y_aggfunc="sum"),
        dbe.elements.Indicator(value="lifeExp"),
        dbe.elements.Table(columns=[
            dict(column="continent"),
            dict(column="gdpPercap", aggfunc="mean")
        ]),
        dbe.elements.Dropdown(value="year", clearable=True),
        dbe.elements.DateRangePicker(date="year_date"),
        dbe.elements.Reset(),
    ]
)
app.layout = ddk.App(children=[state, canvas])

if __name__ == "__main__":
    app.run_server(debug=True)

    """
        ),
        utils.article(
            """

Elements are laid out within the canvas on *cards*, whose size and
position is described in an *arrangement*. When passing in a list of element
objects to `make_state_and_canvas()`, DBE will automatically create and position
one card per element, but the `CanvasConfig` class allows for more direct
control over this process. Internally, `make_state_and_canvas()` uses the
`CanvasConfig` class to generate cards if the `elements` argument is passed
without passing the sibling `arrangement` argument. This means that the
following bits of code are equivalent:

```python
# this code ...
state, canvas = engine.make_state_and_canvas(id="sc",
    elements=[dbe.elements.Bar(...), dbe.elements.Scatter(...)]
    )

# ... does the same thing as this code ...
config = CanvasConfig()
config.add_card(dbe.elements.Bar(...))
config.add_card(dbe.elements.Scatter(...))

state, canvas = engine.make_state_and_canvas(id="sc",
    elements=config.elements,
    arrangement=config.arrangement
    )
```

The `CanvasConfig.add_card()` method also allows a developer to control the
height and width of cards, as well as the x and y coordinates of the top left
corner of cards, on a 12-column grid. The default height and width are both 4,
and the default x and y positions are computed such that cards don't overlap,
meaning that the following bit of code is also equivalent to the two above:

```python
# ... and so does this!
config = CanvasConfig()
config.add_card(dbe.elements.Bar(...), x=0, y=0, h=4, w=4)
config.add_card(dbe.elements.Scatter(...), x=4, y=0, h=4, w=4)

state, canvas = engine.make_state_and_canvas(id="sc",
    elements=config.elements,
    arrangement=config.arrangement
    )
```

In addition to allowing for control over the size and position of cards, the
`CanvasConfig` class provides an easy way of placing more than one element on a
card (by passing in a list of elements rather than a single element). This is
useful to group related elements together, or for elements like dropdowns that
don't take up a lot of vertical space.

Here is a full example of how to use the `CanvasConfig` to position and size
cards and to place more than one element on a card:
    """
        ),
        utils.load_example_string(
            """
import dash
import dash_design_kit as ddk
import plotly.express.data as data
import dashboard_engine as dbe


app = dash.Dash(__name__)
conn_provider = dbe.PandasConnectionProvider(data.gapminder())
engine = dbe.DashboardEngine(app, conn_provider, id="ec1")

config = (
    dbe.CanvasConfig()
    .add_card(dbe.elements.Indicator(value="lifeExp", agg="mean"), h=2, w=2)
    .add_card(
        [
            dbe.elements.Dropdown(value="year", clearable=False),
            dbe.elements.Dropdown(value="continent", clearable=True),
        ], h=2, w=2, y=2
    )
    .add_card(dbe.elements.Bar(x="continent", y="pop", color="continent"))
)
state, canvas = engine.make_state_and_canvas(
    id="sc", elements=config.elements, arrangement=config.arrangement
)
app.layout = ddk.App(children=[state, canvas])

if __name__ == "__main__":
    app.run_server(debug=True)

    """
        ),
        utils.article(
            """

When providing an initial arrangement and set of elements as in the example
above (or if displaying a saved snapshot of a previously-created arrangement), a
canvas can also be made **non-editable** by passing `editable=False` to
`make_state_and_canvas()`.

## Dashboards without Canvases

Non-editable canvases can be used to display arrangements of elements, but using
them in this way is not as flexible as using Dash Design Kit (DDK)’s `Block`,
`Row` and `Card` components. It is possible to build a DBE-powered dashboard
without using a DashboardCanvas, by calling the
engine.make_state_and_components() function. This function returns one
user-invisible store which must be added to the layout, as well as a list of
components, one component per element. These components can be placed in the app
layout anywhere, within any sort of container like an `html.Div` or `ddk.Card`,
as in the following example:
    """
        ),
        utils.load_example_string(
            """
import dash
import dash_design_kit as ddk
import plotly.express.data as data
import dashboard_engine as dbe


app = dash.Dash(__name__)
conn_provider = dbe.PandasConnectionProvider(data.gapminder())
engine = dbe.DashboardEngine(app, conn_provider, id="ec2")

state, components = engine.make_state_and_components(
    id="sc",
    elements=[
        dbe.elements.Bar(x="continent", y="pop", color="continent"),
        dbe.elements.Dropdown(value="year", clearable=False),
        dbe.elements.Dropdown(value="continent", clearable=True),
    ]
)

app.layout = ddk.App(
    children=[
        ddk.Row(
            [
                ddk.Card(components[0]),
                ddk.ControlCard([
                    ddk.ControlItem(components[1]),
                    ddk.ControlItem(components[2])
                ]),
            ]
        ),
        state,
    ],
)

if __name__ == "__main__":
    app.run_server(debug=True)

    """
        ),
    ]
)
