import dash_html_components as html
from .. import utils

layout = html.Div(
    [
        utils.article(
            """
# Limitations and Tradeoffs

Dashboard Engine provides an abstraction for a few common requirements for
self-serve analytical apps:

### Crossfiltering

Dashboard elements interact with each other via the crossfiltering idiom: every
element displays a subset of the dataset the dashboard is connected to and
selections made in one element are reflected. This is a powerful but
non-configurable pattern in DBE. If you require some elements in your app to
respond to each other via some other pattern, such as via hovering instead of
selecting, or running machine learning models instead of filtering, then
although DBE can still be used in your app, you will also need to write some
extra callbacks to implement this custom behavior.

### Drag and Drop Arrangements

Dashboard Engine’s canvas allows end-users to drag and drop elements on the
page. The elements must be Dashboard Engine elements that are either created by
the end-user using the Element Editor or pre-created programmatically using
`CanvasConfig`.

It is currently not possible to use the Canvas to provide drag and drop UI for
arbitrary Dash components (like those in `dash-core-components`,
`dash-html-components`, `dash-design-kit`) without building an element to wrap
them. The API to build your own elements or modify built-in ones is not
currently documented but will be in a future version of DBE.

The drag and drop canvas does not prevent you from writing any code. You will
still need to write code to load data into the UI and provide other layout
elements like an app header. However, it does allow your end users to create
their own arrangements and views on their own without writing code.

### Element Editor

The Element Editor provides a prebuilt UI for creating and editing elements. It
is automatically generated from the data connection: the columns in the editor
are the columns in your dataset.

The Element Editor UI is not currently customizable, and cannot be used
independently of the canvas but it is on our roadmap to enable both of these
use-cases.

## Implementing Dashboard Engine Functionality with Traditional Dash

If you run into the limitations listed above, you can implement some of the
Dashboard Engine functionality with traditional Dash directly in your
application.

* **Crossfiltering & Aggregation** - This can be written using Dash’s callbacks
  and the interactive properties of graphs and tables like `selectedData` and
  `selected_row_ids`. See https://dash.plotly.com/interactive-graphing for an
  example, but such boilerplate can be hard to write and maintain by hand.
* **Drag and Drop** - Re-arranging components is not currently supported by any
  Plotly-maintained component library. You can write your own library using the
  component plugin framework, but it may be difficult.
* **Element Editor** - You can write editors yourself with standard Dash
  controls. In Dashboard Engine, the Element Editor’s dropdowns and values are
  automatically populated based off of the dataset. If you were writing this
  with regular Dash components, you would need to initialize and populate these
  components yourself.
* **Dynamically Adding Charts in the Canvas** - A dynamic number of components
  can be added to a layout via pattern matching callbacks. Correlating charts of
  different types with their matching editor is a significant challenge,
  however.

"""
        )
    ]
)
