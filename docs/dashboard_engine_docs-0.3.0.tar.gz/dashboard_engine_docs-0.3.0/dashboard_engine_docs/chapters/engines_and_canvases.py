import dash_html_components as html
from .. import utils

layout = html.Div(
    [
        # TODO: extracting the data back out
        utils.article(
            """
# Engines, States and Canvases

The basic entry point into Dashboard Engine is an object of class
`DashboardEngine` ("engines") whose constructor accepts a reference to the
current Dash `app` object, and a [connection provider](connecting_to_data). On
construction, engine objects attach callbacks to `app`, which means that engines
*must* be created globally outside of any callback, before the app is run. The
`DashboardEngine` constructor also accepts an optional `id` parameter, which can
be used to create multiple engines within the same app, so long as they have
different IDs.

An engine is be used to create Dash components to place into the app layout via
`make_state_and_canvas()` or `make_state_and_components()`. These functions
*may* be called inside callbacks, so their return values can be used as return
values for callbacks, as is often done when [saving and loading
dashboards](saving-and-loading).

To attach a callback to properties of the state or canvas component, for example
[to update `connection_params`](connecting-to-data), however, we need to access
the `id` property of the component in the callback decorator, so we do need to
call `make_state_and_canvas()` or `make_state_and_components()` once before
defining the callback. In order for this callback to fire even when the state
and canvas are overriden by another callback, the `id` paramter of all
`make_state_and_canvas()` or `make_state_and_components()` calls should match,
as in the following example. Note that `state.id` here is a composite ID that
contains but is not equal to `"dashboard_id"`.

```python
# the ID string here...
state, canvas = engine.make_state_and_canvas(id="dashboard_id")

app.layout = ddk.App(
    html.Div([state, canvas], id="state_and_canvas")
)

@app.callback(Output("state_and_canvas", "children"), Input(...))
def refresh_state_and_canvas(input):
    # ... must match the ID string here ...
    return engine.make_state_and_canvas(id="dashboard_id")

# ... for this callback to work.
@app.callback(Output(state.id, "connection_params"), Input(...))
def refresh_dataset(input):
    return new_connection_params(input)
```
"""
        ),
    ]
)
