import dash_html_components as html
import dashboard_engine as dbe
from .. import utils
import pkg_resources


README_PATH = pkg_resources.resource_filename(
    "dashboard_engine_docs", "chapters/RELEASE_README.md"
)

with open(README_PATH, "r", encoding="utf-8") as f:
    README = f.read()

CONTENTS = README[README.find("Here are the contents of the zip archive:") :]

layout = html.Div(
    [
        utils.article(
            """
# The Distribution Bundle

Dashboard Engine (DBE) v{dbe} is currently in Limited Availability, and is being
distributed as a zip archive containing the docs you are currently reading, as
well as the pip-installable tarballs for DBE itself and a number of ready-to-use
sample applications.

If you would like access to the zip archive distribution, please contact your
Plotly account executive to inquire about joining the Limited Available access
program.

""".format(
                dbe=dbe.__version__
            )
            + CONTENTS
        )
    ]
)
