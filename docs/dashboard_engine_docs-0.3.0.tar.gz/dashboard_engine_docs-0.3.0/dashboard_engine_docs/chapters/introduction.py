import dash_html_components as html
from .. import utils

layout = html.Div(
    [
        # TODO: links
        # TODO: standardize on you/we
        # TODO: mention the "no callbacks needed for crossfilter" somehow
        utils.article(
            """
# Introduction

Dash Enterprise Dashboard Engine (DBE) is a Python package which enables Dash
app developers to [easily add dashboards to their apps](quick-start). DBE-powered
dashboards are collections of [elements, such as charts and controls](elements),
that are [bound to some dataset](connecting-to-data) and automatically interact
with each other via crossfiltering: selections made in one element are reflected
in the others. DBE-powered dashboard canvases are user-editable by default, so
that app users can add, configure and arrange elements without needing to modify
any app code. DBE-powered dashboard configurations can also be [saved and loaded
from a database](saving-and-loading) with the Dash Snapshot Engine.

Dashboard Engine makes it easy to build Dash apps that:

* allow users to modify what the app looks like using the built-in drag and drop
  canvas
* allow users to query and explore datasets using the built-in element editor
* allow users to create, save, restore and share dashboards by integrating with
  Snapshot Engine
* support developer-curated workflows whereby certain power users create views
  of data for other, less advanced users to consume

    """
        )
    ]
)
