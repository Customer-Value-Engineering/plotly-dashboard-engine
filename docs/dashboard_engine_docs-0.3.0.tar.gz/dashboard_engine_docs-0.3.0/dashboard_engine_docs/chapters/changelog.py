import dash_html_components as html
from .. import utils
import pkg_resources

CHANGELOG_PATH = pkg_resources.resource_filename(
    "dashboard_engine_docs", "chapters/CHANGELOG.md"
)

with open(CHANGELOG_PATH, "r", encoding="utf-8") as f:
    CHANGELOG = f.read()

layout = html.Div([utils.article(CHANGELOG)])
