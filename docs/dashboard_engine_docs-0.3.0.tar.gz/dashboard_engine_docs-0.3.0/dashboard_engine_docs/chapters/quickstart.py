import dash_html_components as html
from .. import utils

layout = html.Div(
    [
        # TODO: MP4 video of interaction
        utils.article(
            """
    # Quick Start

    What follows is a walkthrough of the simplest app that makes use of
    Dashboard Engine (DBE). This is the same code as you will find in the
    “minimal” sample app in the [distribution zip archive for
    DBE](distribution). Try clicking on the pencil icon on the right, then the
    plus icon to add and configure a card!

    """
        ),
        utils.load_example_string(
            """
import dash
import dash_design_kit as ddk
import dashboard_engine as dbe
import plotly.express.data as data

df = data.gapminder()

app = dash.Dash(__name__)
conn_provider = dbe.PandasConnectionProvider(df)
engine = dbe.DashboardEngine(app, conn_provider, id="0")
state, canvas = engine.make_state_and_canvas(id="sc")
app.layout = ddk.App(children=[state, canvas])

if __name__ == "__main__":
    app.run_server(debug=True)
    """
        ),
        utils.article(
            """
Walking through this code from the top…


```python

import dash
import dash_design_kit as ddk
import dashboard_engine as dbe
import plotly.express.data as data

df = data.gapminder()
```

* to use DBE, you will need to import Dash, Dash Design Kit (DDK) and DBE, and
  in order to do that, they will need to be [installed in your app's
  environment](installation).
* in this app, we are importing the sample datasets from [Plotly Express
  (PX)](https://plotly.express/) but this is just to get easy access to a Pandas
  dataframe for demonstration purposes

```python
app = dash.Dash(__name__)
```

* the Dash app object must be created before interacting with DBE

```python
connections = dbe.PandasConnectionProvider(df)
engine = dbe.DashboardEngine(app, connections, id="0")
```

* to create a `DashboardEngine` instance, we need a connection provider (see
  [Connections documentation](connecting-to-data) for details). In this case we
  are creating the simplest kind of connection provider: one which binds all
  dashboards created by the engine to the same dataframe created above.
* we then create the engine, passing in the app and connection provider created
  above

```python
state, canvas = engine.make_state_and_canvas(id="sc")
app.layout = ddk.App(children=[state, canvas])
```

* we use the engine to create a user-editable dashboard canvas (see canvas
  documentation for details) and its associated user-invisible state storage.
* an `id` is required, and here we use `"sc"`, short for "state and canvas", but
  any string will do
* our app layout must include a ddk.App for DBE components to function correctly
* here the entire contents of our app are the state and canvas, but as in the
  more complex sample apps and elsewhere in this documentation, these are
  regular Dash components, which can be mixed and matched with other components
  to build a complete app

    """
        ),
    ]
)
