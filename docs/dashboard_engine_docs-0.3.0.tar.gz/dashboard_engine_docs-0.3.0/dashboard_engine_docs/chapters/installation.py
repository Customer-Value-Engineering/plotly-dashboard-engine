import dash_html_components as html
import dash_snapshots as dse
import dash_design_kit as ddk
import dashboard_engine as dbe
from .. import utils

layout = html.Div(
    [
        utils.article(
            """
# Installation

Dashboard Engine (DBE) v{dbe} is currently in Limited Availability, and is being
[distributed as a zip archive](distribution) containing the docs you are
currently reading, as well as the pip-installable tarballs for DBE itself and a
number of ready-to-use sample applications. When DBE reaches General
Availability, these tarballs will be hosted within the Dash Enterprise server
much like the Dash Design Kit (DDK) and Dash Snapshot Engine (DSE) tarballs are,
in the version of Dash Enterprise you currently have licensed.

DBE requires specific versions of DDK and DSE (see below) to function correctly,
so pip-installable tarballs for the latest versions of these libraries are
included in the `dist` directory of the distribution zip archive. To use them
within an app, you will need to copy these tarballs into the top level of your
app directory and commit them into your repo so that they are deployed alongside
your app. You will also need to include the following lines in your
`requirements.txt`

```
./dashboard_engine-{dbe}.tar.gz
./dash_design_kit-{ddk}.tar.gz
./dash_snapshots-{dse}.tar.gz
```

Please note that the DBE tarball contains pinned requirements to recent versions
of `dash`, `plotly` and `pandas` so if you are adding DBE to or upgrading DBE in
an existing app, please be sure to remove any lines from your requirements.txt
that refer to and of these libraries, or DDK, DSE or DBE itself before adding
the lines above to avoid version conflicts.
    """.format(
                dbe=dbe.__version__, ddk=ddk.__version__, dse=dse.__version__
            )
        )
    ]
)
