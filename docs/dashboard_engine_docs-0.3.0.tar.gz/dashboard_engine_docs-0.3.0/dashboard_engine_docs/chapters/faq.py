import dash_html_components as html
from .. import utils

layout = html.Div(
    [
        # TODO: fill with content
        utils.article(
            """
    # Frequently Asked Questions

    Coming soon!
    """
        )
    ]
)
