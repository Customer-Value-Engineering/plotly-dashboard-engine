import dash_html_components as html
import dash_core_components as dcc
import math


def _link(sib, label):
    return html.Div(
        dcc.Link("{}: {}".format(label, sib["name"]), href=sib["url"]),
        style={"border": "thin var(--border) solid", "padding": 5, "margin": 15},
    )


def BottomTOC(pathname, name, siblings):
    return html.Div(
        [
            html.Hr(),
            html.Div(
                [
                    html.Div(
                        _link(siblings["before"], "Previous"),
                        className="bottom-toc--link",
                    ),
                    html.Div(
                        _link(siblings["after"], "Next")
                        if siblings.get("after")
                        else "",
                        className="bottom-toc--link",
                    ),
                ],
                className="bottom-toc--inner",
            ),
            html.Hr(),
        ],
        className="docs-article",
    )
