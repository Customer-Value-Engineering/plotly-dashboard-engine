import dash_html_components as html
import dash_core_components as dcc
import dash_design_kit as ddk
from . import utils


def create_section(children):
    return html.Div(
        [
            html.Div(
                [
                    ddk.Block(
                        child,
                        width=50,
                        margin=0,
                        padding=0,
                        style={
                            "paddingTop": 5,
                            "paddingRight": 35 if i % 2 == 0 else 0,
                        },
                    )
                    for (i, child) in enumerate(children)
                ]
            ),
            html.Br(style={"clear": "both"}),
        ]
    )


def create_section_header(text):
    return ddk.SectionTitle(text)


def create_link_section(href, link_text, description):
    return html.Div(
        children=[
            html.Div(
                dcc.Link(link_text, href=href),
            ),
            dcc.Markdown(description),
        ]
    )


def create_toc(urls):
    children = [
        html.H1(
            "Dashboard Engine Documentation",
            style={
                "textAlign": "center",
                "fontWeight": "bold",
            },
        ),
        utils.article(style={"textAlign": "justify"}, children=urls[0]["description"]),
    ]
    for section in urls:
        if "chapters" in section:
            section_children = []
            for chapter in section["chapters"]:
                section_children.append(
                    create_link_section(
                        chapter["url"], chapter["name"], chapter["description"]
                    )
                )
            children.append(create_section_header(section["name"]))
            children.append(create_section(section_children))

    return html.Div(
        style={"textAlign": "justify"}, children=children, className="docs-article"
    )
