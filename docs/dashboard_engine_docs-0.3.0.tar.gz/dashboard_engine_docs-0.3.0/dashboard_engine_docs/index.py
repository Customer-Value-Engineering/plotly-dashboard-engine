import os
import dash_design_kit as ddk
import dash_core_components as dcc
import dash_html_components as html
from . import chapter_index
from . import utils
from . import components
import datetime
import dashboard_engine as dbe

if os.environ.get("DASH_APP_LOCATION", "") != "ABSOLUTE":
    from .server import app
else:
    from server import app


theme = {"title_capitalization": "capitalize"}


def create_header_menu():
    from . import chapter_index

    menus = []
    for section in chapter_index.URLS:
        if "chapters" in section:
            chapters = []
            for chapter in section["chapters"]:
                chapters.append(
                    dcc.Link(
                        [
                            ddk.Icon(
                                icon_name=chapter.get("icon"),
                                **(
                                    {"icon_category": chapter["icon_category"]}
                                    if "icon_category" in chapter
                                    else {}
                                )
                            ),
                            chapter["name"],
                        ],
                        href=chapter["url"],
                    )
                )
            menus.append(ddk.CollapsibleMenu(title=section["name"], children=chapters))
    return ddk.Menu(menus)


def create_backlinks(pathname):
    parts = pathname.strip("/").split("/")[1:]
    links = [dcc.Link("Home", href=utils.relpath("/"))]
    for i, part in enumerate(parts[0:-1]):
        href = "/".join(parts[: i + 1])
        name = chapter_index.URL_TO_BREADCRUMB_MAP.get(href, "? {} ?".format(href))
        links += [html.Span(" > "), dcc.Link(name, href=href)]
    current_chapter_name = chapter_index.URL_TO_BREADCRUMB_MAP.get(
        pathname.rstrip("/"), "? {} ?".format(pathname)
    )
    links += [html.Span(" > " + current_chapter_name)]
    return links


def content_with_dressing(children, backlinks="", bottom_toc=""):
    return html.Div(
        children=html.Div(
            children=[
                ddk.Header(
                    children=[
                        dcc.Link(
                            href=utils.relpath("/"),
                            children=ddk.Logo(
                                src=utils.relpath("/assets/dash-enterprise-logo.png"),
                            ),
                        ),
                        ddk.Title("Dashboard Engine Documentation"),
                        "v" + dbe.__version__,
                        create_header_menu(),
                    ],
                    style={
                        "position": "sticky",
                        "width": "100%",
                        "top": "0px",
                        "zIndex": 1004,
                    },
                ),
                html.Div(
                    [
                        html.Div(
                            className="dbe-docs-subcontainer content-wrapper",
                            children=[
                                html.Div(
                                    [
                                        html.Div(
                                            children=backlinks,
                                            className="backlinks docs-article",
                                            style={
                                                "borderBottom": "thin var(--border) solid"
                                            }
                                            if backlinks
                                            else {},
                                        ),
                                        html.Div(
                                            html.Div(
                                                children=children,
                                                className="content",
                                                id="content",
                                            ),
                                            className="content-container",
                                        ),
                                        bottom_toc,
                                        html.Div(
                                            children=backlinks,
                                            className="backlinks docs-article",
                                        ),
                                    ],
                                    className="rhs-content container-width",
                                    id="content-parent",
                                ),
                                html.Div(id="pagemenu-container"),
                            ],
                        ),
                        html.Footer(
                            [
                                html.Hr(),
                                html.Div(
                                    "Copyright © {} Plotly. All rights reserved.".format(
                                        datetime.datetime.now().year
                                    ),
                                    className="documentation-footer--content",
                                ),
                            ],
                            className="documentation-footer docs-article",
                        ),
                    ]
                ),
            ]
        ),
        className="dressing-toplevel",
    )


def create_app(theme=theme):
    from . import chapter_index
    from dash.dependencies import Input, Output
    import dash_html_components as html
    import dash_core_components as dcc
    import dash_dangerously_set_inner_html
    import pandas as pd
    from datetime import datetime as dt
    from textwrap import dedent
    import os

    import dash_design_kit as ddk

    app.layout = ddk.App(
        [
            dcc.Location(id="url"),
            html.Div(id="container"),
        ],
        id="dbe-docs-container",
        theme=theme,
    )

    @app.callback(
        Output("container", "children"),
        [Input("url", "pathname")],
    )
    def route(pathname):
        # pathname normalization
        if pathname is None:
            pathname = "/"
        # account for dbe deployed on dds
        if "DASH_APP_NAME" in os.environ:
            normalized_pathname = pathname.replace(
                "/{}".format(
                    os.environ.get(
                        "DASH_APP_NAME",
                    )
                ),
                "",
            )
        else:
            # normal localhost usage
            normalized_pathname = pathname

        underscore_pathname = (
            (normalized_pathname or "").replace("/", "").replace("-", "_")
        )

        if normalized_pathname == "/":
            content = chapter_index.URL_TO_CONTENT_MAP[normalized_pathname]["content"]
            return content_with_dressing(html.Div(content))

        if normalized_pathname in chapter_index.URL_TO_CONTENT_MAP:
            content = chapter_index.URL_TO_CONTENT_MAP[normalized_pathname]["content"]

            backlinks = create_backlinks(normalized_pathname)

            bottom_toc = components.BottomTOC(
                normalized_pathname,
                chapter_index.URL_TO_CONTENT_MAP[normalized_pathname]["name"],
                chapter_index.URL_TO_SIBLINGS_MAP[normalized_pathname],
            )

            return content_with_dressing(
                html.Div(
                    id="breadcrumbs",
                    children=[
                        html.Div(content),
                    ],
                ),
                backlinks=backlinks,
                bottom_toc=bottom_toc,
            )
        else:
            backlinks = create_backlinks(normalized_pathname)

            return content_with_dressing(
                html.Div(
                    [
                        html.H1("404"),
                        html.Hr(),
                        html.H3("Sitemap"),
                        html.Div(
                            [
                                html.Div(
                                    html.Span(
                                        [
                                            html.A(url, href=url),
                                            html.Span(
                                                " ({})".format(
                                                    chapter_index.URL_TO_CONTENT_MAP[
                                                        url
                                                    ]["name"]
                                                )
                                            ),
                                        ]
                                    )
                                )
                                for url in list(
                                    sorted(chapter_index.URL_TO_CONTENT_MAP.keys())
                                )
                            ]
                        ),
                    ]
                ),
                backlinks,
            )

    return app
