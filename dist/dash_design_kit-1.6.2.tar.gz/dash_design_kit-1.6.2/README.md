Production (`master`) deployment status: [![CircleCI](https://circleci.com/gh/plotly/dash-design-kit/tree/master.svg?style=svg&circle-token=89664f2199b26e05861559fe5de2fa043802afb4)](https://circleci.com/gh/plotly/dash-design-kit/tree/master)

Staging (`dev`) deployment status: [![CircleCI](https://circleci.com/gh/plotly/dash-design-kit/tree/dev.svg?style=svg&circle-token=89664f2199b26e05861559fe5de2fa043802afb4)](https://circleci.com/gh/plotly/dash-design-kit/tree/dev)

# Readme

### Project description

Dash Design Kit is one of the four main features of [Dash Enterprise](https://plotly.com/dash/).

Designing, arranging, theming, and styling Dash Open Source apps is one of the hardest things about Dash. Dash Design Kit simplifies this process for our commercial customers enabling them to create branded applications that look great out of the box without any additional work (custom CSS), additional team members (e.g. graphic designers or front-end CSS engineers), nor expertise (learning CSS). This functionality is provided through a theme editor, a set of layout components, a set of speciality design components, and a set of high quality but simple templates.

This makes it cheaper & easier for our customers to use Dash for their projects, enables more developers at our customer's organization to pick up Dash, and helps our customer's apps have a greater impact.

*(from the [Plot-legion operating manual](https://docs.google.com/document/d/14qf5m0d_PMhJAEir4EiFpWFRqcET1OEsqO409hYpKBI/))*

### Installation & Setup

1. Clone this repository using
  - SSH: `git@github.com:plotly/dash-design-kit.git`
  - HTTP: `git clone https://github.com/plotly/dash-design-kit.git`
2. `cd dash-design-kit`
3. (optional) Set up a virtual environment:
  - `virtualenv venv`
  - `. venv/bin/activate`
(Varies based on your shell. For example, if you are using fish you need `. venv/bin/activate.fish`
4. `pip install -r requirements.txt`
5. To run the documentation: `python index.py`

### Contributing 
  See [CONTRIBUTING.md](https://github.com/plotly/dash-design-kit/blob/master/CONTRIBUTING.md).

