# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Block(Component):
    """A Block component.
A layout component used for easily arranging groups of elements.

**Example Usage**
```
app.layout = ddk.App([
    ddk.Block(
        width=30,
        children=[
            # this content takes up 30% of the screen's width
        ]
    ),
    ddk.Block(
        width=70,
        children=[
            # this content takes up 70% of the screen's width
        ]
    ),
    ddk.Block(
        width=50,
        children=[
             # this content wraps onto the next line
             # (below the blocks above) and takes up 50%
             # of the screen's width
        ]
    )
])
```

Keyword arguments:
- children (a list of or a singular dash component, string or number; optional): The list of components that are children of the Block container.
- id (string; optional): The ID of this component, used to identify Dash components
in callbacks. The ID needs to be unique across all of the
components in an app.
- width (number; default 100): Number between 0 and 100 representing the width of the component
with respect to its parent.
- This is a percentage by default: `25` means take up 25% of the space.
- Unless <1, in which it represents a decimal: 0.25 is the same as 25

Note that these units are different than the CSS `style` units where
`style={'width': 25}` means _25 pixels_, not 25%.
- margin (number; default 0): Space (in pixels) surrounding the block.
- padding (number; default 0): Space (in pixels) on the inside of the block, between the border
and the edge of the content.
- style (dict; optional): Optional additional CSS styles.
- If `width`, `padding`, or `margin` are supplied within `style`,
then this will override the component-level `width`, `padding`, or `margin`.
- className (string; optional): Optional user-defined CSS class for the Block container."""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, width=Component.UNDEFINED, margin=Component.UNDEFINED, padding=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'width', 'margin', 'padding', 'style', 'className']
        self._type = 'Block'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'width', 'margin', 'padding', 'style', 'className']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Block, self).__init__(children=children, **args)
