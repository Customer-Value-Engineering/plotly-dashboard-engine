import plotly.io as pio
from plotly.graph_objects import layout

def _setup_template(n_colorway_colors=10, n_colorscale_colors=10):
    colorway = ['var(--colorway-{})'.format(i) for i in range(n_colorway_colors)]
    colorscale = ['var(--colorscale-{})'.format(i) for i in range(n_colorscale_colors)]

    ddk_template = layout.Template({
        'layout': {
            'colorscale': {
                'sequential': list(map(list, (zip([x/(len(colorscale)-1) for x in list(range(len(colorscale)))], colorscale))))
            },
            'colorway': colorway,
            # This will be overridden in graphUtils.js;
            # setting it to 0 (instead of None)
            # so PX will know not to set it in-line (i.e. in figure).
            'margin': {'t': 0}
        }
    })

    pio.templates.default = ddk_template
