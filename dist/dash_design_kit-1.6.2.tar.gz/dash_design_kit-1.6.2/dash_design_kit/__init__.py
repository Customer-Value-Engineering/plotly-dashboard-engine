from __future__ import print_function as _
from pkg_resources import parse_version as _parse_version
from ._notification_manager import notification_manager

import os as _os
import sys as _sys
import json as _json

import dash as _dash

_ddk_needs_polyfills = _parse_version(_dash.__version__) < _parse_version('1.6.1')
_resource_modifier = '.polyfill' if _ddk_needs_polyfills else ''

# noinspection PyUnresolvedReferences
from ._imports_ import *
from ._imports_ import __all__
from ._CopyText import _CopyText

from .import shortcuts
from .import datasets
from ._init_py_ddk_template import _setup_template

_setup_template()

if not hasattr(_dash, '__plotly_dash') and not hasattr(_dash, 'development'):
    print('Dash was not successfully imported. '
          'Make sure you don\'t have a file '
          'named \n"dash.py" in your current directory.', file=_sys.stderr)
    _sys.exit(1)

_basepath = _os.path.dirname(__file__)

_filepath = _os.path.abspath(_os.path.join(_basepath, 'package.json'))
with open(_filepath) as f:
    _package = _json.load(f)

_lock_filepath = _os.path.abspath(_os.path.join(_basepath, 'package-lock.json'))
with open(_lock_filepath) as f:
    _package_lock = _json.load(f)

__version__ = _package['version']
__dcc_version__ = _package_lock['dependencies']['dash-core-components']['version']
__dash_table_version__ = _package_lock['dependencies']['dash-table']['version']
__plotlyjs_version__ = _package_lock['dependencies']['plotly.js']['version']

_current_path = _os.path.dirname(_os.path.abspath(__file__))

_this_module = _sys.modules[__name__]

_async_resources = [
    'graph',
    'plotlyjs'
]

_js_dist = []

_js_dist.extend([{
    'relative_package_path': 'async{}-{}.js'.format(_resource_modifier, async_resource),
    'namespace': 'dash_design_kit',
    'async': True
} for async_resource in _async_resources])

_js_dist.extend([{
    'relative_package_path': 'async{}-{}.js.map'.format(_resource_modifier, async_resource),
    'namespace': 'dash_design_kit',
    'dynamic': True
} for async_resource in _async_resources])

_js_dist.extend([{
    'relative_package_path': 'dash_design_kit{}.min.js'.format(_resource_modifier),
    'namespace': "dash_design_kit"
}, {
    'relative_package_path': 'dash_design_kit{}.min.js.map'.format(_resource_modifier),
    'namespace': "dash_design_kit",
    'dynamic': True
}]);

_css_dist = [
    {
        "relative_package_path": "normalize.css",
        "namespace": "dash_design_kit"
    },
    {
        "relative_package_path": "base.css",
        "namespace": "dash_design_kit"
    },
    {
        "relative_package_path": "bootstrap_build.css",
        "namespace": "dash_design_kit"
    },
    {
        "relative_package_path": "bootstrap_build-override.css",
        "namespace": "dash_design_kit"
    },
    {
        "relative_package_path": "dashboard.css",
        "namespace": "dash_design_kit"
    },
    {
        "relative_package_path": "report.css",
        "namespace": "dash_design_kit"
    },
    {
        "relative_package_path": "fonts.css",
        "namespace": "dash_design_kit"
    },

    {
        "relative_package_path": "fa-all.css",
        "namespace": "dash_design_kit"
    },

    # components
    {
        "relative_package_path": "menu.css",
        "namespace": "dash_design_kit"
    },
    {
        "relative_package_path": "datacard.css",
        "namespace": "dash_design_kit"
    },
    {
        "relative_package_path": "daq-override.css",
        "namespace": "dash_design_kit"
    }
]

for _component in __all__:
    setattr(locals()[_component], '_js_dist', _js_dist)
    setattr(locals()[_component], '_css_dist', _css_dist)
