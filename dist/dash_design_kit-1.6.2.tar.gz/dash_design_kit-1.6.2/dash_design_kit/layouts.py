# -*- coding: utf-8 -*-
import dash_core_components as dcc
import dash_html_components as html
import dash_design_kit as ddk
from datetime import datetime as dt

def Header(children=None, logo=None, menu=None, title=None, height=None):
    if not children:
        children = [];
    return html.Div(
        children=([
            logo,
            ddk.Title(title),
            menu
        ] + children),
        className='layout-header',
        style={'height': height}
    )

def Sidebar(children=None, logo=None, menu=None, title=None, width=None):
    if not children:
        children = [];
    return html.Div(
        children=([
            logo,
            menu,
        ] + children),
        className='layout-sidebar',
        style={'width': width}
    )

def Grid(children=None):
    return dash_design_kit.Grid()
