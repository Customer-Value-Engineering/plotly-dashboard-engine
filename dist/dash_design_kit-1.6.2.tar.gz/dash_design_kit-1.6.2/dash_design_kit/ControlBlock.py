# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class ControlBlock(Component):
    """A ControlBlock component.
A layout component used for easily arranging groups of elements.

**Example Usage**
```
app.layout = ddk.App([
    ddk.Block(
        width=30,
        children=[
            # this content takes up 30% of the screen's width
        ]
    ),
    ddk.Block(
        width=70,
        children=[
            # this content takes up 70% of the screen's width
        ]
    ),
    ddk.Block(
        width=50,
        children=[
             # this content wraps onto the next line
             # (below the cards above) and takes up 50%
             # of the screen's width
        ]
    )
])
```

Keyword arguments:
- children (a list of or a singular dash component, string or number; optional)
- id (string; optional)
- width (number; optional): Number between 0 and 100 representing the width of the component
with respect to its parent.
- This is a percentage by default: `25` means take up 25% of the space.
- Unless <1, in which it represents a decimal: 0.25 is the same as 25

Note that these units are different than the CSS `style` units where
`style={'width': 25}` means _25 pixels_, not 25%.
- margin (number; optional): Space (in pixels) surrounding the card.
- orientation (a value equal to: 'vertical', 'horizontal'; optional): The orientation of the set of controls.
- label_position (a value equal to: 'top', 'left', 'bottom', 'right'; optional): The positon of the label with respect to the control.
- label_text_alignment (a value equal to: 'left', 'right', 'center'; optional): The horizontal label text alignment.
- label_style (dict; optional): Optional additional label CSS styles.
- control_position (a value equal to: 'left', 'right', 'center', 'top'; optional): The control alignment relative to the ControlBlock container.
- padding (string | number; optional): The padding of (i.e. whitespace around) each individual control. Takes `%` int or string `Npx, Nem`, etc. values
- wrap (boolean; optional)
- style (dict; optional): Optional additional CSS styles.
- If `width`, `padding`, or `margin` are supplied within `style`,
then this will override the component-level `width`, `padding`, or `margin`.
- className (string; optional)"""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, width=Component.UNDEFINED, margin=Component.UNDEFINED, orientation=Component.UNDEFINED, label_position=Component.UNDEFINED, label_text_alignment=Component.UNDEFINED, label_style=Component.UNDEFINED, control_position=Component.UNDEFINED, padding=Component.UNDEFINED, wrap=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'width', 'margin', 'orientation', 'label_position', 'label_text_alignment', 'label_style', 'control_position', 'padding', 'wrap', 'style', 'className']
        self._type = 'ControlBlock'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'width', 'margin', 'orientation', 'label_position', 'label_text_alignment', 'label_style', 'control_position', 'padding', 'wrap', 'style', 'className']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(ControlBlock, self).__init__(children=children, **args)
