# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Icon(Component):
    """An Icon component.
[Font Awesome](https://fontawesome.com/) icon component.

Keyword arguments:
- id (string; optional): The ID of this component, used to identify Dash components
in callbacks. The ID needs to be unique across all of the
components in an app.
- className (string; optional): A class name to append to the font-awesome classes.
- icon_name (string; optional): The name of the font-awesome icon without the fa-
- icon_category (a value equal to: 'solid', 'regular', 'brands', 'light'; optional): The Font Awesome category for the icon. One of
     - solid
     - regular
     - brands
- icon_color (string; optional): The icon's color.
- style (dict; optional): Additional style object.
- fa_script (string; optional): A script link to the Font Awesome JavaScript library.
By default, the free icons are included automatically.
If you have a license for the pro icons, then include
your own script with this attribute.
- title (string; optional): Tooltip hover text for the icon. Maps to the underlying
[title](https://developer.mozilla.org/en-US/docs/Web/HTML/Global_attributes/title)
attribute.
- setProps (boolean | number | string | dict | list; optional): Dash-assigned callback that gets fired when the value changes."""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, className=Component.UNDEFINED, icon_name=Component.UNDEFINED, icon_category=Component.UNDEFINED, icon_color=Component.UNDEFINED, style=Component.UNDEFINED, fa_script=Component.UNDEFINED, title=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'className', 'icon_name', 'icon_category', 'icon_color', 'style', 'fa_script', 'title', 'setProps']
        self._type = 'Icon'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'className', 'icon_name', 'icon_category', 'icon_color', 'style', 'fa_script', 'title', 'setProps']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(Icon, self).__init__(**args)
