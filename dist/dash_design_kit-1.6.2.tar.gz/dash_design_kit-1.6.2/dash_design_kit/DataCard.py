# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class DataCard(Component):
    """A DataCard component.
This component will render a styled DataCard with a label, large number, or
sublabel. Style includes handle (with optional icon) or spark trace
if data is provided.

Keyword arguments:
- id (string; optional): The ID of this component, used to identify Dash components
in callbacks. The ID needs to be unique across all of the
components in an app.
- className (string; optional): Optional user-defined CSS class for the DataCard component
- parent_className (string; optional): Optional additional CSS class for the Block container of the DataCard
- value (number | string; optional): The large number
- label (string; optional): The textual label that describes the label
- sub (number | string; optional): A smaller number to accompany `value`
- color (string; optional): Color modifies:
- The background color of the "handle". If not supplied, then this will be the accent color.
- If `trace_y` is supplied, then `color` is the color of the
  graph's line (unless `background_color` is supplied, in which case
  the trace line will be white). If `color` and `background_color`
  aren't supplied, then the color of the line will be the theme's accent
  color.
- trace_x (list; optional): The `x` data in the graph.
- trace_y (list; optional): The `y` data in the graph.
- trace_text (list; optional): The `text` data in the graph (appears on hover)
- icon (string; optional): The font awesome icon name.
This is the same as the `ddk.Icon` `icon_name` property.
- background_color (string; optional): `background_color` is only used if `trace_y` is supplied.
In which case, it will be the background color of the entire DataCard
- text_color (string; optional): The color of the text. If this isn't supplied, then
it will default to the theme's text color.
- margin (number; optional): Space (in pixels) surrounding the DataCard.
Overrides theme.card_header_margin.
- padding (number; optional): Space (in pixels) on the inside of the DataCard, between the border
and the edge of the content.
Overrides theme.card_header_padding.
- box_shadow (string; optional): The box shadow(s) applied to the DataCard. Overrides theme.card_header_box_shadow.
- border_width (string; optional): The border width applied to the DataCard. Overrides theme.card_header_border.width.
- border_style (string; optional): The border style applied to the DataCard. Overrides theme.card_header_border.style.
- border_color (string; optional): The border color applied to the DataCard. Overrides theme.card_header_border.color.
- border_radius (string; optional): The border radius applied to the DataCard. Overrides theme.card_header_border.radius.
- style (dict; optional): Style overrides to the outermost container
- width (number; default 25): The width (in percentage) of the component with respect to its parent.
This is the same type of unit that is used in
`Block`, `Card`, & `ControlCard`.
- setProps (boolean | number | string | dict | list; optional): Dash-assigned callback that gets fired when the value changes."""
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, className=Component.UNDEFINED, parent_className=Component.UNDEFINED, value=Component.UNDEFINED, label=Component.UNDEFINED, sub=Component.UNDEFINED, color=Component.UNDEFINED, trace_x=Component.UNDEFINED, trace_y=Component.UNDEFINED, trace_text=Component.UNDEFINED, icon=Component.UNDEFINED, background_color=Component.UNDEFINED, text_color=Component.UNDEFINED, margin=Component.UNDEFINED, padding=Component.UNDEFINED, box_shadow=Component.UNDEFINED, border_width=Component.UNDEFINED, border_style=Component.UNDEFINED, border_color=Component.UNDEFINED, border_radius=Component.UNDEFINED, style=Component.UNDEFINED, width=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'className', 'parent_className', 'value', 'label', 'sub', 'color', 'trace_x', 'trace_y', 'trace_text', 'icon', 'background_color', 'text_color', 'margin', 'padding', 'box_shadow', 'border_width', 'border_style', 'border_color', 'border_radius', 'style', 'width', 'setProps']
        self._type = 'DataCard'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'className', 'parent_className', 'value', 'label', 'sub', 'color', 'trace_x', 'trace_y', 'trace_text', 'icon', 'background_color', 'text_color', 'margin', 'padding', 'box_shadow', 'border_width', 'border_style', 'border_color', 'border_radius', 'style', 'width', 'setProps']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(DataCard, self).__init__(**args)
