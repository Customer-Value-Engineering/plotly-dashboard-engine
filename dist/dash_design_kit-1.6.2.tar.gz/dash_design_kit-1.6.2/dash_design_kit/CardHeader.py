# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class CardHeader(Component):
    """A CardHeader component.
A header component designed to be the first child of a `Card` or `ControlCard`.
Takes `title` (string), `fullscreen`, and `modal` (bool) arguments, in addition
to `children[]` designed to contain Dash Core Components (DCC) controls
(e.g. `dcc.Dropdown`, `dcc.DatePickerRange`), or other components meant to be
displayed in the bottom of the card.

Note that placing a string in `title` and a string in `children` will have a similar effect.
The only differences are that the title string will be bolded and that the children
property can include other components like controls (not just strings).

**Example Usage**
```
app.layout = ddk.App([
    ddk.Card(width=70,
        children=[
            # Allow the card to be expanded to fullscreen or modal
            # Set the expanded modal dimensions to 80%
            ddk.CardHeader(
               dcc.DatePickerRange(
                   start_date=datetime.datetime(2019, 1, 1),
                   end_date=datetime.datetime(2020, 8, 1)
               ),
               title='String card title',
               modal=True, fullscreen=True,
               modal_config={'width': 80, 'height': 80}),
            ddk.Graph(id="sample-graph-id", figure={
                 'data': [{
                   'x': [1, 2, 3, 4],
                   'y': [4, 1, 6, 9],
                   'line': {'shape': 'spline'}
                }]
            }),
        ],
    ),
])
```

Keyword arguments:
- children (a list of or a singular dash component, string or number; optional): The list of components that are children of the CardHeader container.
These children should be Dash Core Components (DCC) controls
(e.g. `dcc.Dropdown`, `dcc.DatePickerRange`),
or other components meant to be displayed in the top of the card.
- id (string; optional): The ID of this component, used to identify Dash components
in callbacks. The ID needs to be unique across all of the
components in an app.
- title (string; optional): string or Dash component; optional
- modal (boolean; optional): Displays an icon that allows the card to be expanded to a modal.
- modal_container_className (string; optional): The optional className of the modal container if modal=True
- copy (boolean; optional): Displays an icon that allows the card's innerText to be copied
to the clipboard.
- modal_config (dict; optional): Object that takes 'width' and 'height' arguments to define modal dimensions
Width or height can either be a string or a num N that gets converted to N%. modal_config has the following type: dict containing keys 'width', 'height'.
Those keys have the following types:
  - width (string | number; optional)
  - height (string | number; optional)
- fullscreen (boolean; optional): Displays an icon that allows the card to be expanded to a modal.
- margin (number; optional): Space (in pixels) surrounding the CardHeader.
Overrides theme.card_header_margin.
- padding (number; optional): Space (in pixels) on the inside of the CardHeader, between the border
and the edge of the content.
Overrides theme.card_header_padding.
- background_color (string; optional): The background color applied to the CardHeader. Overrides theme.card_header_background_color.
- box_shadow (string; optional): The box shadow(s) applied to the CardHeader. Overrides theme.card_header_box_shadow.
- border_width (string; optional): The border width applied to the CardHeader. Overrides theme.card_header_border.width.
- border_style (string; optional): The border style applied to the CardHeader. Overrides theme.card_header_border.style.
- border_color (string; optional): The border color applied to the CardHeader. Overrides theme.card_header_border.color.
- border_radius (string; optional): The border radius applied to the CardHeader. Overrides theme.card_header_border.radius.
- style (dict; optional): Optional additional CSS styles.
- If `width`, `padding`, or `margin` are supplied within `style`,
then this will override the component-level `width`, `padding`, or `margin`.
- className (string; optional): Optional user-defined CSS class for the CardHeader container."""
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, title=Component.UNDEFINED, modal=Component.UNDEFINED, modal_container_className=Component.UNDEFINED, copy=Component.UNDEFINED, modal_config=Component.UNDEFINED, fullscreen=Component.UNDEFINED, margin=Component.UNDEFINED, padding=Component.UNDEFINED, background_color=Component.UNDEFINED, box_shadow=Component.UNDEFINED, border_width=Component.UNDEFINED, border_style=Component.UNDEFINED, border_color=Component.UNDEFINED, border_radius=Component.UNDEFINED, style=Component.UNDEFINED, className=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'title', 'modal', 'modal_container_className', 'copy', 'modal_config', 'fullscreen', 'margin', 'padding', 'background_color', 'box_shadow', 'border_width', 'border_style', 'border_color', 'border_radius', 'style', 'className']
        self._type = 'CardHeader'
        self._namespace = 'dash_design_kit'
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'title', 'modal', 'modal_container_className', 'copy', 'modal_config', 'fullscreen', 'margin', 'padding', 'background_color', 'box_shadow', 'border_width', 'border_style', 'border_color', 'border_radius', 'style', 'className']
        self.available_wildcard_properties =            []

        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        for k in []:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')
        super(CardHeader, self).__init__(children=children, **args)
